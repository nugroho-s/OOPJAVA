/* File name: supermain.java */

import java.util.Scanner;
/**
 * @author Nugroho Satriyanto / 13514038
 */
public class supermain{
	/**
         * int yang berfungsi sebagai global time
         */
	public static int global_time = 0;
        
	/**
         * method untuk menampulkan pesan pembuka
         */
	public static void print_pesanPembuka() {
		System.out.println("---------------VERSI 2.B--=------------");
		System.out.println("Dunia sabana berhasil terbentuk");
		System.out.println("Silahkan board.tambahkan makhluk ke dalamnya");
		System.out.println("Tekan tombol: ");
		System.out.println(" * z untuk ZEBRA");
		System.out.println(" * k untuk KURA2");
		System.out.println(" * i untuk KELINCI");
		System.out.println(" * s untuk SINGA");
		System.out.println(" * e untuk ELANG");
		System.out.println(" * u untuk ULAR");
		System.out.println(" * x untuk selesai");
	}

	/**
         * method untuk menampilkan string ss
         * @param ss , string yang akan ditampilkan
         */
        public static void print_Umum(String ss) {
		System.out.println(ss);
	}

        /**
         * method untuk menampilkan string dan int
         * @param ss , string yang akan ditampilkan
         * @param ii , int yang akan ditampilkan
         */
	public static void print_Umum_i1(String ss, int ii) {
		System.out.println(ss + ii);
	}

        /**
         * method untuk menampilkan hasil persaingan antar makhluk dalam satu sel
         * @param nm , nama makhluk
         * @param vid , id makhluk
         * @param ps , posisi sel
         * @param hasil_saing  , hasil dari persaingan
         */
	public static void print_HasilPersaingan(char nm, int vid, Point ps, String hasil_saing) {
		System.out.println("[Info] Hasil persaingan");
		System.out.println("-----------------------");
		System.out.println("ID makhluk: " + vid);
		System.out.println("Nama makhluk: " + nm);
		System.out.println("Sel yang diperebutkan: " + ps.getX() + ", " + ps.getY());
		System.out.println("Hasil persaingan: " + hasil_saing);
		if (hasil_saing == "kalah") {
			System.out.println("Makhluk dieliminasi dari board");
		}
		System.out.println("-----------------------");
	}

        /**
         * method untuk menampilkan status dari target
         * @param nm , nama makhluk
         * @param vid , id dari makhluk
         * @param pt , Point dari target
         */
	public static void print_StatusTarget(char nm, int vid, Point pt) {
		System.out.println("[Info] Status Target");
		System.out.println("-------------------------");
		System.out.println("ID makhluk: " + vid);
		System.out.println("Nama makhluk: " + nm);
		System.out.println("Posisi target: " + pt.getX() + ", " + pt.getY());
		System.out.println("Berhasil mencapai target!");
		System.out.println("-------------------------");
	}

        /**
         * method untuk menampilkan posisi target
         * @param tgt , makhluk yang menjadi target
         * @param krn , makhluk yang menjadi karnivora
         */
	public static void print_posisiTarget(makhluk tgt, makhluk krn) {
		System.out.println("[Info] Karnivora mendeteksi herbivora");
		System.out.println("-------------------------------------");
		System.out.println("ID karnivora: " + krn.getunique());
		System.out.println("Posisi karnivora: " + krn.getlok().getX() + ", " + krn.getlok().getY());
		System.out.println("Target terdeteksi di: " + tgt.getlok().getX() + ", " + tgt.getlok().getY());
		System.out.println("-------------------------------------");
	}

        /**
         * method untuk menampilkan makhluk yang mati kelaparan
         * @param nm, nama makhluk
         * @param vid, id makhluk
         * @param pt , point dari makhluk
         */
	public static void print_MatiKelaparan(char nm, int vid, Point pt) {
		System.out.println("[Info] Makhluk mati karena kelaparan");
		System.out.println("------------------------------------");
		System.out.println("ID makhluk: " +  vid);
		System.out.println("Nama makhluk: " + nm);
		System.out.println("Posisi mati: " + pt.getX() + ", " + pt.getY());
		System.out.println("------------------------------------");
	}

        /**
         * method untuk menampilkan posisi dari makhluk
         * @param nm , nama makhluk
         * @param pt , posisi dari makhluk
         * @param vid , id dari makhluk
         */
	public static void print_SearchPath(String nm, Point pt, int vid) {
		System.out.println("[Info] Search Path");
		System.out.println("------------------");
		System.out.println("ID makhluk: "+vid);
		System.out.println("Nama makhluk: "+ nm);
		System.out.println("Posisi makhluk: "+pt.getX()+", "+pt.getY());
		System.out.println("------------------");
	}

        /**
         * method untuk mencetak makhluk sekarang
         * @param cm ,jenis makhluk
         * @param nm , nama makhluk
         */
	public static void print_CurrMakhluk(makhluk cm, char nm) {
		System.out.println("[Move] Makhluk bergerak");
		System.out.println("-----------------------");
		System.out.println("ID makhluk: " + cm.getunique());
		System.out.println("Nama makhluk: " + nm);
	}

        /**
         * method untuk menampilkan Point
         * @param pt , Point
         */
	public static void print_Point(Point pt) {
		System.out.println("(" + pt.getX() + ", " + pt.getY() + ")");
	}

	/**
         * main program
         * @param args , parameter program utama
         */
	public static void main(String[] args){
		
		//KAMUS
		char keyObj = '0';
		board b = new board();
		int bnykobj = 0;
        list LOM = new list("lom");
        char[] vObj = new char[30];
        makhluk temp;
		makhluk[] mptr = new makhluk[30];
        int jmakhluk = 0;
        
        Scanner baca = new Scanner(System.in);
        
        //ALGORITMA
        keyObj = baca.next().charAt(0);
        
        while (keyObj!='x'){
			
            keyObj = baca.next().charAt(0);
			if (keyObj == 'z') {
				vObj[bnykobj]='z';
				System.out.println("Anda menambahkan zebra");
			} else if (keyObj == 'k') {
				vObj[bnykobj]=('k');
				System.out.println("Anda menambahkan kura2");
			} else if (keyObj == 'i') {
				vObj[bnykobj]=('i');
				System.out.println("Anda menambahkan kelinci");
			} else if (keyObj == 's') {
				vObj[bnykobj]=('s');
				System.out.println("Anda menambahkan singa");
			} else if (keyObj == 'e') {
				vObj[bnykobj]=('e');
				System.out.println("Anda menambahkan elang");
			} else if (keyObj == 'u') {
				vObj[bnykobj]=('u');
				System.out.println("Anda menambahkan ular");
			}
			bnykobj++;
        }
		System.out.println();
		System.out.println();
		System.out.println("Penambahan awal selesai");
		
		// menampilkan informasi hasil penambahan
		System.out.println("Total makhluk: " + bnykobj);
		System.out.println("Informasi umum");
		System.out.println("--------------");
        
		for (int i=0;i<bnykobj;i++){
            if (vObj[i] == 'z') {
				mptr[i] = new zebra(board.min_h_vertical, board.max_h_vertical, board.min_h_horizontal, board.max_h_horizontal);
				b.tambah(mptr[i], 'Z');
				mptr[i].printunique("zebra");
			} else if (vObj[i] == 'k') {
				mptr[i] = new kura2(board.min_h_vertical, board.max_h_vertical, board.min_h_horizontal, board.max_h_horizontal);
				b.tambah(mptr[i], 'K');
				mptr[i].printunique("kura");
			} else if (vObj[i] == 'i') {
				mptr[i] = new kelinci(board.min_h_vertical, board.max_h_vertical, board.min_h_horizontal, board.max_h_horizontal);
				b.tambah(mptr[i], 'I');
				mptr[i].printunique("kelinci");
			} else if (vObj[i] == 's') {
				mptr[i] = new singa(board.min_k_vertical, board.max_k_vertical, board.min_k_horizontal, board.max_k_horizontal);
				b.tambah(mptr[i], 'S');
				mptr[i].printunique("singa");
			} else if (vObj[i] == 'e') {
				mptr[i] = new elang(board.min_k_vertical, board.max_k_vertical, board.min_k_horizontal, board.max_k_horizontal);
				b.tambah(mptr[i], 'E');
				mptr[i].printunique("elang");
			} else if (vObj[i] == 'u') {
				mptr[i] = new ular(board.min_k_vertical, board.max_k_vertical, board.min_k_horizontal, board.max_k_horizontal);
				b.tambah(mptr[i], 'U');
				mptr[i].printunique("ular");
			}
			mptr[i].printlok();
        }
        System.out.println();
		System.out.println("Kondisi awal board");
		System.out.println("------------------");
		b.printboard();
		
		// membuat path ke pintu_s utk herbivora (karnivora belum punya target saat kehidupan dimulai)
		for (int i = 0; i < bnykobj; i++) {
		
			if (mptr[i].getid() == 'h') {
				System.out.println("Membuat path gerak untuk makhluk dengan ID: "+ mptr[i].getunique());
				mptr[i].makepath(mptr[i].gettarget());
				mptr[i].isiLOP();
			}
		}
		
		// memasukannya ke dalam LOM
		//list LOM = new list("lom");
		
		System.out.println("Memasukkan semua makhluk ke dalam List Of Makhluk (LOM)");
		
		for (int i = 0; i < bnykobj; i++) {
			if (vObj[i] == 'z') {
				LOM.addNode(mptr[i], 'Z', mptr[i].getunique());
			} else if (vObj[i] == 'k') {
				LOM.addNode(mptr[i], 'K', mptr[i].getunique());
			} else if (vObj[i] == 'i') {
				LOM.addNode(mptr[i], 'I', mptr[i].getunique());
			} else if (vObj[i] == 's') {
				LOM.addNode(mptr[i], 'S', mptr[i].getunique());
			} else if (vObj[i] == 'e') {
				LOM.addNode(mptr[i], 'E', mptr[i].getunique());
			} else if (vObj[i] == 'u') {
				LOM.addNode(mptr[i], 'U', mptr[i].getunique());
			}
		}
		
		
		int found;
		makhluk target_pointer;
		list.node curr;
		list.node st;
		Point pointSTR = new Point();			//posisi awal gerak makhluk 
		Point pointLOP = new Point();			//posisi tujuan gerak makhluk 
		Point random_point = new Point();		//posisi makhluk setelah bergerak random 1 langkah
		Point temp_target = new Point();		//posisi herbivora yang terdeteksi oleh karnivora 
		char nama_mkhlk;
		char ah;
		int temp_x, temp_y;	
		int timer;
		int dunia_on = 1;

	
		while (dunia_on == 1) {

			global_time++;
			curr = LOM.head;
			
			while (curr != null) { // menggerakkan objek satu-satu  

			if (curr.mptr.getIsExist() == 1) {

				if(global_time % curr.mptr.getdt() == 0) {
					// menyimpan posisi awal makhluk sebelum bergerak 
					pointSTR = curr.mptr.getlok();
					
					supermain.print_CurrMakhluk(curr.mptr, curr.nama_makhluk);

					if (curr.mptr.getid() == 'h') {
						
						//makhluk bernama nama_mkhlk bergerak ke posisi (pointLOP.x, pointLOP.y) dari posisi awal (pointSTR.x, pointSTR.y) 
						if (curr.mptr.getkejar() == null) {    
							// menyimpan posisi tujuan makhluk pada posisi ke-idx_obj di LOP secara normal (gerak 1 langkah)
							pointLOP = curr.mptr.getElmtLOP(curr.mptr.getMTimer() + 1);
							curr.mptr.setMTimer(curr.mptr.getMTimer() + 1);
							
							// cek apakah terjadi persaingan pada sebuah sel hasil gerakan random karnivora 
							clonemain.persainganSel(pointLOP, LOM.head, curr);
							
							if (curr.mptr.getIsExist() == 0) {
							
								b.hapus(curr.mptr);
								
								supermain.print_HasilPersaingan(curr.nama_makhluk, curr.mptr.getunique(), pointLOP, "kalah");
								
							
							} else {
								
								nama_mkhlk = curr.nama_makhluk;
								curr.mptr.bergerak(nama_mkhlk, pointSTR, pointLOP);
								
								curr.mptr.printstatgerak(pointSTR, pointLOP);
								curr.mptr.printstatkelaparan();
								
								if (curr.mptr.getlapar() < 0) {

									// ubah nilai isExist
									curr.mptr.setIsExist(0);

									supermain.print_MatiKelaparan(curr.nama_makhluk, curr.mptr.getunique(), pointLOP);
								}
								
								curr.mptr.setP(pointLOP);
								System.out.println("Status: herbivora tidak sedang dikejar");
							
							}
							
						} else {
							// menyimpan posisi tujuan makhluk pada posisi ke-idx_obj di LOP secara extreme (gerak lgkh_max langkah)
							pointLOP = curr.mptr.getElmtLOP(curr.mptr.getMTimer() + curr.mptr.getLMax());
							curr.mptr.setMTimer(curr.mptr.getMTimer() + curr.mptr.getLMax());
						
							// cek apakah terjadi persaingan pada sebuah sel hasil gerakan random karnivora 
							clonemain.persainganSel(pointLOP, LOM.head, curr);
							
							if (curr.mptr.getIsExist() == 0) {
								
								// set nilai mengejar milik karnivora yang mengejar menjadi null 
								curr.mptr.getkejar().setkejar(null);
								
								// menghapus herbivora dari board 
								b.hapus(curr.mptr);
								
								// menghapus LOP karnivora 
								curr.mptr.getkejar().delpath();

								
								supermain.print_HasilPersaingan(curr.nama_makhluk, curr.mptr.getunique(), pointLOP, "kalah");
								

							} else {
					
								nama_mkhlk = curr.nama_makhluk;
								curr.mptr.bergerak(nama_mkhlk, pointSTR, pointLOP);
								
								curr.mptr.printstatgerak(pointSTR, pointLOP);
								curr.mptr.printstatkelaparan();
								
								if (curr.mptr.getlapar() < 0) {
									// set nilai mengejar milik karnivora yang mengejar menjadi null 
									curr.mptr.getkejar().setkejar(null);
								
									// ubah nilai isExist
									curr.mptr.setIsExist(0);

									// menghapus makhluk dari board
									b.hapus(curr.mptr);

									
									print_MatiKelaparan(curr.nama_makhluk, curr.mptr.getunique(), pointLOP);
								}
								
								curr.mptr.setP(pointLOP);
								System.out.println("Status: herbivora sedang dikejar, langkahnya semakin cepat");
					
							}
							
						}
						
						//cek apakah sebuah objek sudah berhasil mendapatkan targetnya
						if (curr.mptr.getIsExist() == 1) {
							if (curr.mptr.getlok().getX() == curr.mptr.gettarget().getX() && curr.mptr.getlok().getY() == curr.mptr.gettarget().getY()) {
								
								// menampilkan pesan bahwa makhluk berhasil mencapai target
								
								print_StatusTarget(curr.nama_makhluk, curr.mptr.getunique(), curr.mptr.gettarget());

								//hapus target dari board
								b.hapus(curr.mptr);
								
								//ubah nilai isExist milik target 
								curr.mptr.setIsExist(0);
								
								//set nilai mengejar oleh karnivora menjadi null 
								if (curr.mptr.getkejar() != null) {
									curr.mptr.getkejar().setkejar(null);
								}
								
							} 
						}
						
					} else {
						
						if (curr.mptr.getkejar() == null) { // karnivora tidak sedang mengejar herbivora 
							
							// karnivora bergerak secara random 1 langkah 
							random_point.set(curr.mptr.getlok().getX(), curr.mptr.getlok().getY());
							random_point = curr.mptr.bergerak_random(board.isi, board.sizex, board.sizey);
							
							// cek apakah terjadi persaingan pada sebuah sel hasil gerakan random karnivora 
							clonemain.persainganSel(random_point, LOM.head, curr);
							
							if (curr.mptr.getIsExist() == 0) {
								
								// jika kalah dalam persaingan, maka dihapus dari board 
								b.hapus(curr.mptr);
								
								if (curr.mptr.getlapar() > 0) 
									
									print_HasilPersaingan(curr.nama_makhluk, curr.mptr.getunique(), random_point, "kalah");

							} else {
							
								// menggerakkan karnivora ke random_point
								nama_mkhlk = curr.nama_makhluk;
								curr.mptr.bergerak(nama_mkhlk, pointSTR, random_point);
								
								curr.mptr.printstatgerak(pointSTR, random_point);
								curr.mptr.printstatkelaparan();
								
								curr.mptr.setP(random_point);
							
								// melakukan deteksi terhadap keberadaan herbivora dalam jangkauan arah geraknya 
								if (curr.mptr.getlapar() >= 0) {

									karnivora.iterate_lom = LOM.head;
									karnivora.kar = curr;
									curr.mptr.lihat(temp_target);
			
									if (temp_target.getX() != -1 && temp_target.getY() != -1) {

										// set target 
										curr.mptr.setTarget(temp_target);
								
										// iterasi LOM untuk mendapatkan pointer makhluk yang ada di posisi temp_target

										target_pointer = clonemain.find_target_pointer(temp_target, LOM.head);
								
										// target terdeteksi 
										print_posisiTarget(target_pointer, curr.mptr);

										// set nilai mengejar karnivora menjadi target pointer 
										curr.mptr.setkejar(target_pointer);
										target_pointer.setkejar(curr.mptr);
								
										// membuat path awal ke target pointer 
										curr.mptr.makepath(temp_target);
										curr.mptr.isiLOP();
									
										
									} else {
										// target tidak terdeteksi 
										// do nothing - belum perlu membuat path ke target 
										System.out.println("Status: karnivora tidak sedang mengejar (gerak random)");
									}
								} else {

									//ubah nilai isExist
									curr.mptr.setIsExist(0);
								
									// menghapus makhluk dari board
									b.hapus(curr.mptr);

									
									print_MatiKelaparan(curr.nama_makhluk, curr.mptr.getunique(), random_point);
								}
							}
								
						} else { // karnivora sedang mengejar herbivora 
							
							// menyimpan posisi tujuan makhluk pada posisi ke-idx_obj di LOP secara extreme (gerak lgkh_max langkah)
							pointLOP = curr.mptr.getElmtLOP(curr.mptr.getMTimer() + curr.mptr.getLMax());
							curr.mptr.setMTimer(curr.mptr.getMTimer() + curr.mptr.getLMax());
							
							// cek apakah terjadi persaingan pada sebuah sel hasil gerakan menurut LOP karnivora 
							clonemain.persainganSel(pointLOP, LOM.head, curr);
							
							if (curr.mptr.getIsExist() == 0) {
								
								// set nilai dikejar untuk herbivora yang dikejar menjadi null 
								curr.mptr.getkejar().setkejar(null);
								
								// hapus karnivora dari board 
								b.hapus(curr.mptr);

								
								print_HasilPersaingan(curr.nama_makhluk, curr.mptr.getunique(), random_point, "kalah");
								
								
							} else {
								nama_mkhlk = curr.nama_makhluk;
								curr.mptr.bergerak(nama_mkhlk, pointSTR, pointLOP);
							
								curr.mptr.printstatgerak(pointSTR, pointLOP);
								curr.mptr.printstatkelaparan();
							
								curr.mptr.setP(pointLOP);
							
								// membuat path baru ke target, karena posisi target pasti berubah 
								if (curr.mptr.getlapar() >= 0) {
									temp_target = curr.mptr.getkejar().getlok();
									
									// set target 
									curr.mptr.setTarget(temp_target);
								
									//cek apakah sebuah objek sudah berhasil mendapatkan targetnya
									if (curr.mptr.getlok().getX() == curr.mptr.gettarget().getX() && curr.mptr.getlok().getY() == curr.mptr.gettarget().getY()) {
										
										// menampilkan pesan bahwa makhluk berhasil mencapai target
										print_StatusTarget(curr.nama_makhluk, curr.mptr.getunique(), curr.mptr.gettarget());

										//set level kelaparan menjadi sangat kenyang  
										curr.mptr.setMLapar();
								
										//ubah nilai isExist milik target 
										curr.mptr.getkejar().setIsExist(0);
								
										//set nilai mengejar menjadi null 
										curr.mptr.setkejar(null);
								
										//menghapus LOP karnivora 
										curr.mptr.delpath();
							
								
									} else {
										// membuat path awal ke target pointer
										curr.mptr.delpath();
										curr.mptr.makepath(temp_target);
										curr.mptr.isiLOP();
									}

									System.out.println("Status: karnivora sedang mengejar");
								} else {
									//ubah nilai isExist 
									curr.mptr.setIsExist(0);
								
									//set nilai mengejar menjadi null 
									curr.mptr.setkejar(null);
								
									//menghapus LOP karnivora 
									curr.mptr.delpath();

									// menghapus makhluk dari board
									b.hapus(curr.mptr);
									
									
									print_MatiKelaparan(curr.nama_makhluk, curr.mptr.getunique(), pointLOP);
								}
							}
						}
						
					}

					//tampilkan pergerakan ke layar
					System.out.println("[Info] Kondisi board sekarang");
					System.out.println("-----------------------------");
					b.printboard();
					System.out.println("press any key to continue");
								
				}
			}

				curr = curr.next;

				//Sleep(1000);
			
			}

			list.node PP = LOM.head;
			while (PP != null){
				if (PP.mptr.getIsExist() == 0)
					PP = PP.next;
				else
					break;
			}
			if (PP == null)
				dunia_on = 0;


		}
		System.out.println("KEHIDUPAN SABANA SELESAI");
	}
}