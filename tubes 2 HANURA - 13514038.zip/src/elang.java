/* File name: elang.java */
/**
 * @author Jeremia Kavin Raja P. / 13514060
 */
public class elang extends karnivora {
	
	/**
         * constructor
         * @param p1 , Point batas
         * @param p2 , Point batas
         * @param p3 , Point batas
         * @param p4 , Point batas
         */
	public elang(Point p1, Point p2, Point p3, Point p4){
		super(p1, p2, p3, p4);
		mlapar = maxlapar;
		power = 4;
		dt = 1;
		arah = 0;
		mengejar = null;					// belum ada objek yang sedang dikejar
		target.set(-1, -1);					// inisiasi awal belum punya target yang sedang dikejar 
		lgkh_max = 3;						// maksimum bergerak 3 langkah saat mengejar herbivora
		// inisiasi list of path kosong
		LOP = new list();
		LOP.headp = null;
		LOP.tailp = null;
	}
	
	/**
         * menaikkan mlapar ke maxlapar
         */
	public void makan(){
		mlapar = maxlapar;
	}
	
        /**
         * buat jalur elang menuju _target
         * @param _target , makhluk target
         */
	public void makepath(Point _target){
		
		// membuat path ke pintu_s dan menyimpannya ke dalam list of path (LOP)
		
		/**
		* membuat objek dari PathTree: 
		* 	inisiasi array stat (menyatakan apakah sebuah posisi sudah dijadikan node / belum)
		* 	inisiasi address dari node root (node paling atas)
		* 	inisiasi found_target
		* 	inisiasi array ptree (menyimpan tree)
		* 	memasukkan posisi awal sebuah elang di board (yang nilainya random) ke dalam ptree sebagai elemen ke-0 
		*/
		PathTree PT = new PathTree(P);
		
		/** argumen ke-1 bernilai 1 berarti melakukan pemanggilaan prosedur MakeTree pertama kali **/
		PT.MakeTree(1, 0, 0, target);
		
		/** memasukkan path ke dalam LOP **/
		Node ptarget = new Node();
		ptarget = PT.SearchNode(Node.proot, Node.ptree[Node.found_target]);
		Node curr = new Node();
		curr = ptarget;

		if (curr == null) { 
			System.out.println("null"); 
		}
		
		while (curr != null) { //selama belum sampai di proot 
			//memasukannya ke dalam LOP 
			LOP.addPathFirst(curr.getAkar());
			curr = curr.getParent();
		}

		//print_Umum("press any key to continue");
		//getchar();
		
	}
}
