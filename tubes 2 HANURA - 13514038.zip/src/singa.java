/**
 * 
 * @author Harry Oktavianus Purba / 13514050
 */

public class singa extends karnivora {

	/**
         * konstruktor
         * @param p1 , batas
         * @param p2 , batas
         * @param p3 , batas
         * @param p4 , batas
         */
	public singa(Point p1, Point p2, Point p3, Point p4)  {
		super(p1, p2, p3, p4);
		mlapar = maxlapar;
		power = 5;
		dt = 1;
		arah = 0;
		mengejar = null;					// belum ada objek yang sedan dikejar
		target.set(-1, -1);					// inisiasi awal belum punya target yang sedang dikejar 
		lgkh_max = 3;						// maksimum bergerak 3 langkah saat mengejar herbivora 
		// inisiasi list of path kosong
		LOP = new list();
		LOP.headp = null;
		LOP.tailp = null;
	}
	
	/**
         * memakan objek lain. level kelaparannya menjadi maxlapar (sangat kenyang) 
         */
	public void makan(){
		// memakan objek lain. level kelaparannya menjadi maxlapar (sangat kenyang) 
		mlapar = maxlapar;
	}
        /**
         * membuat path ke pintu_s dan menyimpannya ke dalam list of path (LOP)
         * @param target_ , tujuan
         */
	public void makepath(final Point target_) { 
		
		// membuat path ke pintu_s dan menyimpannya ke dalam list of path (LOP)
		
		/**
		* membuat objek dari PathTree: 
		* 	inisiasi array stat (menyatakan apakah sebuah posisi sudah dijadikan node / belum)
		* 	inisiasi address dari node root (node paling atas)
		* 	inisiasi found_target
		* 	inisiasi array ptree (menyimpan tree)
		* 	memasukkan posisi awal sebuah singa di board (yang nilainya random) ke dalam ptree sebagai elemen ke-0 
		*/
		PathTree PT = new PathTree(P);
		
		/** argumen ke-1 bernilai 1 berarti melakukan pemanggilaan prosedur MakeTree pertama kali **/
		PT.MakeTree(1, 0, 0, target);
		
		/** memasukkan path ke dalam LOP **/
		Node ptarget = new Node();
		ptarget = PT.SearchNode(Node.proot, Node.ptree[Node.found_target]);
		Node curr = new Node();
		curr = ptarget;

		if (curr == null) { 
			System.out.println("null"); 
		}
		
		while (curr != null) { //selama belum sampai di proot 
			//memasukannya ke dalam LOP 
			LOP.addPathFirst(curr.getAkar());
			curr = curr.getParent();
		}

		//print_Umum("press any key to continue");
		//getchar();
		
		
	}
}
