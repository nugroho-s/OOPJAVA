/* File name: Point.java */

/**
 * @author Nugroho Satriyanto / 13514038
 */
public class Point {
    /**
     * absis dari Point
     */
    private int x;
    
    /**
     * ordinat dari Point
     */
    private int y;

    /**
    * Constructor
    */
    public Point(){
		x = 0;
		y = 0;
	};

    // Getter
    /**
     * method untuk mendapatkan absis dari suatu Point
     * @return x, absis dari Point
     */
    public int getAbsis(){
		return x;
	};
    
    /**
     * method untuk mendapatkan ordinat dari suatu Point
     * @return y, ordinat dari Point
     */
    public int getOrdinat(){
		return y;
	};
    
    /**
     * method untuk mendapatkan absis dari suatu Point
     * @return x, absis dari Point
     */
    public int getX(){
        return x;
    }
    
    /**
     * method untuk mendapatkan ordinat dari suatu Point
     * @return y, ordinat dari Point
     */
    public int getY(){
        return y;
    }

    // Setter
    /**
     * method untuk mengatur absis dari suatu Point
     * @param x , int yang akan menjadi absis dari Point
     */
    public void setAbsis(int x){
		this.x = x;
	};
    
    /**
     * method untuk mengatur ordinat dari suatu Point
     * @param y , int yang akan menjadi ordinat dari Point
     */
    public void setOrdinat(int y){
		this.y = y;
	};
    
    /**
     * method untuk mengatur absis dan ordinat dari suatu Point
     * @param x , int yang akan menjadi absis dari Point
     * @param y , int yang akan menjadi ordinat dari Point
     */
    public void set(int x,int y){
        this.x = x;
        this.y = y;
    }

    // Predikat
    /**
     * method untuk memeriksa apakah suatu Point berada di titik Origin (0, 0)
     * @return 1, jika Point berada di (0, 0)
     * @return 0, jika Point tidak berada di (0, 0)
     */
    public int isOrigin(){
		if ((getAbsis()==0)&&(getOrdinat()==0))
			return 1;
		else
			return 0;
	};

    // Operator Relasional
    /**
     * method yang memeriksa apakah suatu Point sama dengan p
     * @param p , Point yang akan dijadikan acuan pemeriksaan
     * @return 1, jika Point sama dengan p
     * @return 0, jika Point tidak sama dengan p
     */
    public int isEqual(Point p){
		if ((getAbsis()==p.getAbsis())&&(getOrdinat()==p.getOrdinat()))
			return 1;
		else
			return 0;
	};

    // Operator aritmetika
    /**
     * method yang menghasilkan Point hasil penjumlahan p1 dan p2
     * @param p1 , Point yang akan dijumlahkan
     * @param p2 , Point yang akan dijumlahkan
     * @return P, Point hasil penjumlahan p1 dan p2
     */
    public Point add(Point p1, Point p2){
		Point P = new Point();
		P.setAbsis(p1.getAbsis()+p2.getAbsis());
		P.setOrdinat(p1.getOrdinat()+p2.getOrdinat());
		return P;
	};

    /**
     * method untuk menambahkan Point dengan Point o
     * @param o , Point yang akan ditambahkan
     * @return P, Point hasil penjumlahan antara suatu Point dengan Point o
     */
    public Point add(Point o){
		Point P = new Point();
		P.setAbsis(getAbsis()+o.getAbsis());
		P.setOrdinat(getOrdinat()+o.getOrdinat());
		return P;
	}; // menghasilkan current objek+P

    /**
     * method untuk menambahkan absis Point dengan x dan ordinat Point dengan y
     * @param x , int yang akan ditambahkan pada absis Point
     * @param y , int yang akan ditambahkan pada ordinat Point
     * @return P, Point hasil penjumlahan antara Point dengan (x, y)
     */
    public Point add(int x, int y){
		Point P = new Point();
		P.setAbsis(this.getAbsis() + x);
		P.setOrdinat(this.getOrdinat() + y);
		return P;
	};

    /**
     * method untuk menambahkan suatu Point dengan Point p
     * @param p , Point yang akan ditambahkan
     */
    public void addToMe(Point p){
		setAbsis(getAbsis()+p.getAbsis());
		setOrdinat(getOrdinat()+p.getOrdinat());
	};

    /**
     * method untuk menambahkan suatu Point dengan (x, y)
     * @param x , int yang akan ditambahkan ke absis dari Point
     * @param y , int yang akan ditambahkan ke ordinat dari Point
     */
    public void addToMe(int x, int y){
		setAbsis(getAbsis()+x);
		setOrdinat(getOrdinat()+y);
	};

    /**
     * method yang akan mencerminkan suatu Point terhadap garis y=x
     */
    public void mirror(){
		int temp = getAbsis();
		setAbsis(getOrdinat());
		setOrdinat(temp);
	};

    // Fungsi lain
    // Menghasilkan nomor kuadran dari titik sekarang
    // Sebuah titik yang berada pada sumbu x atau y tidak akan dicoba
    /**
     * method yang akan mengembalikan nilai kuadran dari suatu Point
     * @return 1/2/3/4, merupakan nilai kuadran dari suatu Point
     */
    public int kuadran(){
		if (getAbsis()>0){
			if(getOrdinat()>0)
				return 1;
			return 4;
		}
		else{
			if (getOrdinat()>0)
				return 2;
			return 3;
		}
	};

    // Menghasilkan sebuah titik yang merupakan hasil mirror dengan garis y = x
    /**
     * method untuk mengembalikan Point berupa cerminan dirinya terhadap y=x
     * @return P, dimana P adalah Point yang dicerminkan tehadap garis y=x
     */
    public Point mirrorOfMe(){
		Point P = new Point();
		P.setAbsis(getOrdinat());
		P.setOrdinat(getAbsis());
		return P;
	};
}