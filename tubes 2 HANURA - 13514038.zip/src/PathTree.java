/* File name: PathTree.java */

/**
 * @author Jeremia Kavin Raja P. / 13514060
 */
public class PathTree {

	/**
         * berfungsi untuk menjadi penunjuk batas depan array yang akan diproses
         */
        private int PASSHEAD;
        /**
         * berfungsi untuk menjadi penunjuk batas belakang array yang akan diproses
         */
	private int PASSTAIL;
        /**
         * berfungsi sebagai Node dari PathTree
         */
	public Node p;

	/**
         * Constructor
         * @param position , Point yang akan dijadikan sebagai Akar dari PathTree
         */
	public PathTree(Point position){
		p = new Node();
		Node.stat = new int[board.sizey][board.sizex];
		for (int i = 0; i < board.sizey; i++) {
			for (int j = 0; j < board.sizex; j++) {
				Node.stat[i][j] = 0;
			}
		}
		Node.proot = null;
		Node.found_target = -1;
		Node.ptree = new Point[board.sizex * board.sizey * 8];
		for (int i = 0; i < board.sizex * board.sizey * 8; i++) {
			Node.ptree[i].set(-1, -1);
		}
		/** memasukkan posisi awal sebuah kura di board (yang nilainya random) ke dalam ptree sebagai elemen ke-0 **/
		Node.ptree[0].set(position.getX(), position.getY());
	}
	
	/**
         * method yang berfungsi untuk memeriksa apakah suatu PathTree memiliki timur/tenggara/selatan/baratdaya/barat/utara/timurlaut
         * @return true apabila timur, tenggara, selatan, baratdaya, barat, baratlaut, utara, timurlaut bernilai null
         * @return false apabila salah satu dari atribut tersebut tidak bernilai null
         */
	public boolean isOneElmt(){
		if (p.getTimur() == null && p.getTenggara() == null && p.getSelatan() == null && p.getBaratDaya() == null 
		 && p.getBarat() == null && p.getBaratLaut() == null && p.getUtara() == null && p.getTimurLaut() == null) {
			return true;
		}
		else {
			return false;
		}
	}

        /**
         * method yang berfungsi untuk memeriksa apakah pada stat[py][px] berisi 0 ((px,py) tidak terdapat di PathTree
         * @param px , nilai x yang akan menjadi indeks kedua di stat
         * @param py , nilai y yang akan menjadi indeks pertama di stat
         * @return true, apabila nilai (px, py) tidak terdapat pada PathTree
         * @return false, apabila nilai (px, py) terdapat pada PathTree
         */
	public boolean isnotinptree(int px, int py){
		if (Node.stat[py][px] == 0) { //belum pnya child 
			return true;
		} else {
			return false;
		}
	}
	
        /**
         * method untuk mencari Node yang berisi nilai Point pp
         * @param T , Node akar dari PathTree
         * @param pp , Point yang merupakan akar dari Node yang akan dicari
         * @return addr , address Node yang dicari
         */
	public Node SearchNode(Node T, Point pp){
		Node cek_timur = null;
		Node cek_tenggara = null;
		Node cek_selatan = null;
		Node cek_baratdaya = null;
		Node cek_barat = null;
		Node cek_baratlaut = null;
		Node cek_utara = null;
		Node cek_timurlaut = null;
		
		if (isOneElmt()) {
			if (Node.proot.getAkar().getX() == pp.getX() && p.getAkar().getY() == pp.getY()) {
				//node berhasil ditemukan di address par 
				//System.out.println("Node found");
				return Node.proot;
			} 
		} else {
			if (T.getTimur() != null) {
				/*
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getTimur());
				cek_timur.set(ntemp.SearchNode(pp));
				*/
				
				cek_timur = SearchNode(T.getTimur(), pp);
				
				if (cek_timur != null) {
					return cek_timur;
				}
			} 
			if (p.getTenggara() != null && cek_timur == null) {
				//System.out.println("search tenggara");
				/*
				cek_tenggara = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getTenggara());
				cek_tenggara.set(nTemp.SearchNode(pp));
				*/
				
				cek_tenggara = SearchNode(T.getTenggara(), pp);
				
				if (cek_tenggara != null) {
					return cek_tenggara;
				}
			} 
			if (p.getSelatan() != null && cek_timur == null && cek_tenggara == null) {
				//System.out.println("search selatan");
				/*
				cek_selatan = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getSelatan());
				cek_selatan.set(ntemp.SearchNode(pp));
				*/
				
				cek_selatan = SearchNode(T.getSelatan(), pp);
				
				if (cek_selatan != null) {
					return cek_selatan;
				}
			} 
			if (p.getBaratDaya() != null && cek_timur == null && cek_tenggara == null && cek_selatan == null) {
				//System.out.println("search baratdaya");	
				/*
				cek_baratdaya = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getBaratDaya());
				cek_baratdaya.set(ntemp.SearchNode(pp));
				*/
				
				cek_baratdaya = SearchNode(T.getBaratDaya(), pp);
				
				if (cek_baratdaya != null) {
					return cek_baratdaya;
				}
			} 
			if (p.getBarat() != null && cek_timur == null && cek_tenggara == null && cek_selatan == null && cek_baratdaya == null) {
				//System.out.println("search barat");	
				/*
				cek_barat = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getBarat());
				cek_barat.set(ntemp.SearchNode(pp));
				*/
				
				cek_barat = SearchNode(T.getBarat(), pp);
				
				if (cek_barat != null) {
					return cek_barat;
				}
			} 
			if (p.getBaratLaut()!= null && cek_timur == null && cek_tenggara == null && cek_selatan == null && cek_baratdaya == null && cek_barat == null) {
				//System.out.println("search baratlaut");	
				/*
				cek_baratlaut = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getBaratLaut());
				cek_baratlaut.set(ntemp.SearchNode(pp));
				*/
				
				cek_baratlaut = SearchNode(T.getBaratLaut(), pp);
				
				if (cek_baratlaut != null) {
					return cek_baratlaut;
				}
			} 
			if (p.getUtara()!= null && cek_timur == null && cek_tenggara == null && cek_selatan == null && cek_baratdaya == null && cek_barat == null && cek_baratlaut == null) { 
				//System.println("search utara");	
				/*
				cek_utara = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getUtara());
				cek_utara.set(ntemp.SearchNode(pp));
				*/
				
				cek_utara = SearchNode(T.getUtara(), pp);
				
				if (cek_utara != null) {
					return cek_utara;
				}
			} 
			if (p.getTimurLaut() != null && cek_timur == null && cek_tenggara == null && cek_selatan == null && cek_baratdaya == null && cek_barat == null && cek_baratlaut == null && cek_utara == null) {
				//System.out.println("search timurlaut");	
				/*
				cek_timurlaut = new Node();
				PathTree ntemp = new PathTree();
				ntemp.p.set(p.getTimurLaut());
				cek_timurlaut.set(ntemp.SearchNode(pp));
				*/
				
				cek_timurlaut = SearchNode(T.getTimurLaut(), pp);
				
				if (cek_timurlaut != null) {
					return cek_timurlaut;
				}
			}
		}
		
		return null;
	}
	
	/**
         * method yang berfungsi untuk membangun pohon dari path yang akan dilalui makhluk, dimana sebuah node akan menyimpan koordinat dari titik yang akan dilalui makhluk
         * @param idx_ptree , index dari array yang akan diproses
         * @param ph , nilai penunjuk HEAD dari sebuah array
         * @param pt , nilai penunjuk TAIL dari sebuah array
         * @return pparent , address node yang menjadi parent (root) dari sebuah subtree
         */
        public Node Tree(int idx_ptree, int ph, int pt) {
		
		//KAMUS
		int pos_x, pos_y;
		int temp_passhead;
		Node pparent;
		Node ptimur;
		Node ptenggara;
		Node pselatan;
		Node pbaratdaya;
		Node pbarat;
		Node pbaratlaut;
		Node putara;
		Node ptimurlaut;

		//ALGORITMA
		
		/** mendapatkan posisi elemen terakhir di ptree **/ 
		int ii;
		for (ii = 0; ii < board.sizex * board.sizey * 8; ii++) {
			if (Node.ptree[ii].getX() == -1 && Node.ptree[ii].getY() == -1) {
				break; 
			}
		}
			PASSHEAD = ii;
			temp_passhead = ii;
			
			pos_x = Node.ptree[idx_ptree].getX();
			pos_y = Node.ptree[idx_ptree].getY();
			
			//timur
			if (pos_x+1 < board.sizex) {
				if (board.isi[pos_y][pos_x+1] != '!' && board.isi[pos_y][pos_x+1] != 'q' && isnotinptree(pos_x+1, pos_y) == true) {
					ptimur = new Node();
					ptimur.setAkar(pos_x+1, pos_y);
					ptimur.setTimur(null); ptimur.setTenggara(null); ptimur.setSelatan(null); ptimur.setBaratDaya(null);
					ptimur.setBarat(null); ptimur.setBaratLaut(null); ptimur.setUtara(null); ptimur.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x+1, pos_y);
					temp_passhead++;
			
				} else { ptimur = null; }
			} else { ptimur = null; }
			//tenggara
			if (pos_x+1 < board.sizex && pos_y+1 < board.sizey) {
				if (board.isi[pos_y+1][pos_x+1] != '!' && board.isi[pos_y+1][pos_x+1] != 'q' && isnotinptree(pos_x+1, pos_y+1) == true) {
					ptenggara = new Node();
					ptenggara.setAkar(pos_x+1, pos_y);
					ptenggara.setTimur(null); ptenggara.setTenggara(null); ptenggara.setSelatan(null); ptenggara.setBaratDaya(null);
					ptenggara.setBarat(null); ptenggara.setBaratLaut(null); ptenggara.setUtara(null); ptenggara.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x+1, pos_y+1);
					temp_passhead++;
				
				} else { ptenggara = null; }
			} else { ptenggara = null; }
			//selatan
			if (pos_y+1 < board.sizey) {
				if (board.isi[pos_y+1][pos_x] != '!' && board.isi[pos_y+1][pos_x] != 'q' && isnotinptree(pos_x, pos_y+1) == true) {
					pselatan = new Node();
					pselatan.setAkar(pos_x+1, pos_y);
					pselatan.setTimur(null); pselatan.setTenggara(null); pselatan.setSelatan(null); pselatan.setBaratDaya(null);
					pselatan.setBarat(null); pselatan.setBaratLaut(null); pselatan.setUtara(null); pselatan.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x, pos_y+1);
					temp_passhead++;
				
				} else { pselatan = null; }
			} else { pselatan = null; }
			//barat daya
			if (pos_y+1 < board.sizey && pos_x-1 >= 0) {
				if (board.isi[pos_y+1][pos_x-1] != '!' && board.isi[pos_y+1][pos_x-1] != 'q' && isnotinptree(pos_x-1, pos_y+1) == true) {
					pbaratdaya = new Node();
					pbaratdaya.setAkar(pos_x+1, pos_y);
					pbaratdaya.setTimur(null); pbaratdaya.setTenggara(null); pbaratdaya.setSelatan(null); pbaratdaya.setBaratDaya(null);
					pbaratdaya.setBarat(null); pbaratdaya.setBaratLaut(null); pbaratdaya.setUtara(null); pbaratdaya.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x-1, pos_y+1);
					temp_passhead++;
				
				} else { pbaratdaya = null; }
			} else { pbaratdaya = null; }
			//barat
			if (pos_x-1 >= 0) {
				if (board.isi[pos_y][pos_x-1] != '!' && board.isi[pos_y][pos_x-1] != 'q' && isnotinptree(pos_x-1, pos_y) == true) {
					pbarat = new Node();
					pbarat.setAkar(pos_x+1, pos_y);
					pbarat.setTimur(null); pbarat.setTenggara(null); pbarat.setSelatan(null); pbarat.setBaratDaya(null);
					pbarat.setBarat(null); pbarat.setBaratLaut(null); pbarat.setUtara(null); pbarat.setTimurLaut(null);
			
					Node.ptree[temp_passhead].set(pos_x-1, pos_y);
					temp_passhead++;
				
				} else { pbarat = null; }
			} else { pbarat = null; }
			//barat laut
			if (pos_y-1 >= 0 && pos_x-1 >= 0) {
				if (board.isi[pos_y-1][pos_x-1] != '!' && board.isi[pos_y-1][pos_x-1] != 'q' && isnotinptree(pos_x-1, pos_y-1) == true) {
					pbaratlaut = new Node();
					pbaratlaut.setAkar(pos_x+1, pos_y);
					pbaratlaut.setTimur(null); pbaratlaut.setTenggara(null); pbaratlaut.setSelatan(null); pbaratlaut.setBaratDaya(null);
					pbaratlaut.setBarat(null); pbaratlaut.setBaratLaut(null); pbaratlaut.setUtara(null); pbaratlaut.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x-1, pos_y-1);
					temp_passhead++;
				
				} else { pbaratlaut = null; }
			} else { pbaratlaut = null; }
			//utara
			if (pos_y-1 >= 0) {
				if (board.isi[pos_y-1][pos_x] != '!' && board.isi[pos_y-1][pos_x] != 'q' && isnotinptree(pos_x, pos_y-1) == true) {
					putara = new Node();
					putara.setAkar(pos_x+1, pos_y);
					putara.setTimur(null); putara.setTenggara(null); putara.setSelatan(null); putara.setBaratDaya(null);
					putara.setBarat(null); putara.setBaratLaut(null); putara.setUtara(null); putara.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x, pos_y-1);
					temp_passhead++;
				
				} else { putara = null; } 
			} else { putara = null; }
			//timur laut 
			if (pos_y-1 >= 0 && pos_x+1 < board.sizex) {
				if (board.isi[pos_y-1][pos_x+1] != '!' && board.isi[pos_y-1][pos_x+1] != 'q' && isnotinptree(pos_x+1, pos_y-1) == true) {
					ptimurlaut = new Node();
					ptimurlaut.setAkar(pos_x+1, pos_y);
					ptimurlaut.setTimur(null); ptimurlaut.setTenggara(null); ptimurlaut.setSelatan(null); ptimurlaut.setBaratDaya(null);
					ptimurlaut.setBarat(null); ptimurlaut.setBaratLaut(null); ptimurlaut.setUtara(null); ptimurlaut.setTimurLaut(null);
				
					Node.ptree[temp_passhead].set(pos_x+1, pos_y-1);
					temp_passhead++;
				
				} else { ptimurlaut = null; }
			} else { ptimurlaut = null; }
			
			// membentuk node parent dari kumpulan child node di atas 
			//pparent = new Node();
			if (Node.proot == null) { // tree masih kosong 
				pparent = null;
			} else {
				// search node yang punya nilai Point sama dengan ptree ke idx_ptree
				/*
				PathTree ntemp = new PathTree();
				ntemp.p.set(Node.proot);
				pparent.set(ntemp.SearchNode(Node.ptree[idx_ptree]));
				*/
				
				// search node yang punya nilai Point sama dengan ptree ke idx_ptree
				pparent = SearchNode(Node.proot, Node.ptree[idx_ptree]);
			}
			
			/*
			Point PO = new Point();
			PO.set(pos_x, pos_y);
			pparent.setAkar(PO);
			Node.stat[pos_y][pos_x] = 1;		// sudah pnya child 
			*/
			
			pparent.setAkar(pos_x, pos_y);
			Node.stat[pos_y][pos_x] = 1;
			
			//menghubungkan parent node dengan child node untuk membentuk sebuah PathTree 
			pparent.setTimur(ptimur);
			if (ptimur != null) {
				ptimur.setParent(pparent);
			} 
			
			pparent.setTenggara(ptenggara);
			if (ptenggara != null) {
				ptenggara.setParent(pparent);
			}
			
			pparent.setSelatan(pselatan);
			if (pselatan != null) {
				pselatan.setParent(pparent);
			}
			
			pparent.setBaratDaya(pbaratdaya);
			if (pbaratdaya != null) {
				pbaratdaya.setParent(pparent);
			}
			
			pparent.setBarat(pbarat);
			if (pbarat != null) {
				pbarat.setParent(pparent);
			}
			
			pparent.setBaratLaut(pbaratlaut);
			if (pbaratlaut != null) {
				pbaratlaut.setParent(pparent);
			}
			
			pparent.setUtara(putara);
			if (putara != null) {
				putara.setParent(pparent);
			}
			
			pparent.setTimurLaut(ptimurlaut);
			if (ptimurlaut != null) {
				ptimurlaut.setParent(pparent);
			}
		
			//pembentukan sebuah PathTree berhasil

			//mengembalikan nilai tail yang baru (disimpan di passtail)
			if (PASSHEAD > temp_passhead-1) { //jika tidak ada child node yang terbentuk 
				PASSTAIL = PASSHEAD;
				//System.out.println("no child node created");
			} else {
				PASSTAIL = temp_passhead-1;
				//System.out.println("child node created");
			}
		
			return pparent;
	}
	
	/**
         * method yang akan menghasilkan PathTree dengan child dan parent node sudah dialokasikan
         * @param idx_call , variabel yang menyimpan sudah berapa kali method ini dipanggil
         * @param HEAD , variabel penunjuk HEAD dari sebuah array ptree
         * @param TAIL , variabel penunjuk TAIL dari sebuah array ptree
         * @param TARGET , variabel penyimpan posisi target sebuah makhluk
         */ 
	public void MakeTree(int idx_call, int HEAD, int TAIL, Point TARGET) {
		
		//KAMUS 
		Node PP;
		int head, tail;
		int counter;
		
		//ALGORITMA 
		head = HEAD;
		tail = TAIL;
		counter = head;
		
		/** cek apakah di ptree sudah terdapat node target **/
		for (int i = counter; i <= tail; i++) {
			if (Node.ptree[i].getX() == TARGET.getX() && Node.ptree[i].getY() == TARGET.getY()) {
				Node.found_target = i;
				break;
			}
		}
		
		/** mendapatkan address dari node parent (sebuah koordinat di board) **/
		if (Node.found_target == -1) {
			
			while ((counter < tail) || (counter == tail && idx_call == 1) || (counter == tail && idx_call != 1 && Node.ptree[counter].getX() != -1 && Node.ptree[counter].getY() != -1)) {
				PASSHEAD = -1;
				PASSTAIL = -1;
				PP = Tree(counter, PASSHEAD, PASSTAIL); 
				//jika baru pertama kali memanggil MakeTree, maka inisiasi address node paling atas (proot)
				//menjadi PP 
				if (idx_call == 1) {
					Node.proot = PP;
					Node.proot.setParent(null);
				}
				
				//sampai sini ptree menyimpan banyak child node dari node PP 
				MakeTree(0, PASSHEAD, PASSTAIL, TARGET);
				if (Node.found_target == -1) {
					counter++;
				} else {
					break;
				}
			}
			
		}
	}
}
