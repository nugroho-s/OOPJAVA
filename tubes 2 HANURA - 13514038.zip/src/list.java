/* File name: list.java */

/**
 * @author Nugroho Satriyanto / 13514038
 */
public class list{
    //atribut
    
    
    static class node{
        /**
         * char yang mengidentifikasi makhluk
         * Z = zebra; S = singa; K = kura2; I = kelinci; U = ular; E = elang
         */
        public char nama_makhluk;
        /**
         * makhluk yang sedang ditunjuk oleh pointer
         */
        public makhluk mptr;
        /**
         * ID yang menyatakan keunikan dari setiap makhluk
         */
        public int id_unique;
        /**
         * Node berikutnya
         */
        public node next;
    }
    /**
     * Node yang menunjuk ke kepala sebuah list
     */
    public node head;
    /**
     * Node yang menunjuk ke ekor sebuah list
     */
    public node tail;
    
	static class path{
            /**
             * P adalah Point yang terdapat di P
             * nextp adalah struktur path yang menunjuk ke path berikutnya
             */
		Point P;
		path nextp;
	}
    
    /**
     * pointer yang menunjuk ke path kepala sebuah list
     */
    public path headp;
    /**
     * pointer yang menunjuk ke path ekor sebuah list
     */
    public path tailp;
    /**
     * nama dari list
     */
    String nama_list;
    
    //methods
    /**
     * constructor
     */
    list(){
        nama_list = "lop";
        headp = null;
        tailp = null;
    };
    /**
     * constructor
     * @param s , string yang menjadi nama list
     */
    list(String s){
        nama_list = s;
        head = null;
        tail = null;
    };
    
    /**
     * method yang memeriksa kekosongan suatu list
     * @return true jika list kosong
     * @return false jika list tidak kosong
     */
    boolean isEmpty(){
        if (!nama_list.equals("lom")) {
            if (headp == null && tailp == null) {
                return true; 
            } else {
                return false;
            }
        } else {
            if (head == null && tail == null) {
                return true; 
            } else {
                return false;
            }
        }
    }
    
    /**
     * method yang menambahkan node ke dalam list makhluk hidup
     * @param m, makhluk yang ingin ditambahkan
     * @param nama_mkhlk , karakter pembeda setiap makhluk
     * @param id_unq , id dari setiap makhluk yang dibuat unik
     */
    void addNode(makhluk m, char nama_mkhlk, int id_unq) {
		// inisialisasi node baru utk ditambahkan
		node ptr = new node();
		
		ptr.mptr = m;
		ptr.nama_makhluk = nama_mkhlk;
		ptr.id_unique = id_unq;
		
		// menambahkan ke dalam list sbg elemen terakhir
		if (head == null) { // jika list kosong, firstElmt = addedElmt
			head = ptr;
			tail = ptr;
			tail.next = null;
		} else { // list berisi
			tail.next = ptr;
			ptr.next = null;
			tail = ptr;
		}
    }
    
    /**
     * method yang memeriksa apakah list hanya terdiri atas satu elemen
     * @return true apabila list hanya terdiri atas satu elemen
     * @return false apabila list tidak hanya terdiri atas satu elemen
     */
    boolean isOneElmt() {
	if (nama_list.equals("lom")) {
		if (head != null && head.next == null) {
			return true;
		} else {
			return false;
		}
	} else {
		if (headp != null && headp.nextp == null) {
			return true;
		} else {
			return false;
		}
	}
    }
    
    /***
     * method yang menambahkan path ke dalam list sebagai elemen pertama
     * @param p , path yang ingin ditambahkan ke list
     */
    void addPathFirst(Point p) {
		path ptr = new path();
		int px, py;
		
		px = p.getX();
		py = p.getY();
		ptr.P.set(px, py);
		
		// menambahkan ke dalam list sbg elemen terdepan 
		if (headp == null) { // jika list kosong, firstElmt = addedElmt
			headp = ptr;
			tailp = ptr;
			tailp.nextp = null;
		} else { // list berisi
			ptr.nextp = headp;
			headp = ptr;
		}
    }
    
    /**
     * method yang menambahkan Point ke dalam list sebagai elemen terakhir
     * @param p , Point yang akan ditambahkan ke dalam list
     */
    void addPath(Point p) {
		// inisialisasi path baru utk ditambahkan
		path ptr = new path();
    	int px, py;
    	
		px = p.getX();
		py = p.getY();
		ptr.P.set(px, py);
		
		// menambahkan ke dalam list sbg elemen terakhir
		if (headp == null) { // jika list kosong, firstElmt = addedElmt
			headp = ptr;
			tailp = ptr;
		} else { // list berisi
			tailp.nextp = ptr;
			ptr.nextp = null;
			tailp = ptr;
		}
    }
    
    /**
     * method yang digunakan untuk menghapus Node dari dalam path
     * @param ptr , node yang akan dihapus dari dalam list
     */
    void deleteNode(node ptr) {
		node temp = ptr;
		node prev = head;
		if (isEmpty()) {
			System.out.println("list kosong tidak bisa dihapus");
		} else {
			if (temp == prev) {
				head = head.next;
				if (tail == temp) {
					tail = tail.next;
				}
			} else {
				while (prev.next != ptr) {
						prev = prev.next;
				}
				prev.next = temp.next;
				if (tail == temp) {
					tail = prev;
				}
			}
		}
    }
    
    /**
     * method yang digunakan untuk menghapus path dari list
     * @param ptr , path yang akan dihapus dari list
     */
    void deletePath(path ptr) {
		path temp = ptr;
		path prev = headp;
		if (isEmpty()) {
			System.out.println("list kosong tidak bisa dihapus");
		} else {
			if (temp == prev) {
				headp = headp.nextp;
				if (tailp == temp) {
					tailp = tailp.nextp;
				}
			} else {
				while (prev.nextp != ptr) {
					prev = prev.nextp;
				}
				prev.nextp = temp.nextp;
				if (tailp == temp) {
					tailp = prev;
				}
			}
		}
    }
    
    /**
     * method untuk menghapus semua path dari dalam list
     */
    void deleteAllPath() {
        path current;
        current = headp;
     
        while(current != null) {
			current = current.nextp;
        }
        headp = null;
        tailp = null;
    }

    /**
     * method yang digunakan untuk mencetak list node ke layar
     * @param ptr , node pertama yang akan dicetak
     */
    void printList(node ptr) {
		System.out.println("[Info] Isi list node");
		System.out.println("--------------------");
		if (isEmpty()) {
			System.out.println("menampilkan list kosong");
		} else {
			while (ptr != null) {
				System.out.println(ptr.mptr.getpower());
				ptr = ptr.next;
			}
		}
    }
    
    /**
     * method yang digunakan untuk mencetak isi list path ke layar
     * @param ptr , path pertama yang akan dicetak
     */
    void printListPath(path ptr) {
		System.out.println("[Info] Isi list path");
		System.out.println("--------------------");
		if (isEmpty()) {
			System.out.println("menampilkan list kosong");
		} else {
			while (ptr != null) {
				supermain.print_Point(ptr.P);
				ptr = ptr.nextp;
			}
		}
	}
}