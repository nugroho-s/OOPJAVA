/* File name: clonemain.java */

// default empty constructor will be called by the compiler

/**
 * @author Nugroho Satriyanto / 13514038
 * @author Harry Octavianus Purba / 13514050
 * @author Jeremia Kavin Raja P. / 13514060
 * @author Albertus Kelvin / 13514100
 */
public class clonemain {
	
        /**
         * method yang akan digunakan para makhluk untuk mencari musuh
         * @param t_p , Point yang menyatakan letak target
         * @param ptr , Node yang akan disimpan dalam sebuah list
         * @return currp.mptr, Makhluk yang akan dikejar
         */
	public static makhluk find_target_pointer(Point t_p, list.node ptr) {
		// return address pointer target
		list.node currp;
		int x_node, y_node;
		
		currp = ptr;
		while (currp != null) {
			x_node = currp.mptr.getlok().getX();
			y_node = currp.mptr.getlok().getY();
		
			if (x_node == t_p.getX() && y_node == t_p.getY()) {
				if (currp.mptr.getid() == 'h') {
					//pointer target ditemukan
					break;
				}
			} 
			currp = currp.next;
		}
		
		return currp.mptr;
	}
	
        /**
         * method yang menangani saat ada dua objek berada di sel layar yang sama
         * @param t_p , Point dari objek lainnya
         * @param nd , addresslist yang menyatakan head dari list
         * @param cr , adddress list yang menyatakan makhlik yang sekarang hidup
         */
	public static void persainganSel(Point t_p, list.node nd, list.node cr) {
		/* menentukan siapa yang pada akhirnya menang dalam persaingan sebuah sel di board 
		   makhluk yang kalah akan dihapus (di set nilai isExist nya menjadi 0)
		*/
		
		while (nd != null) {
			//cek apakah di sel t_p terdapat makhluk lain 
			if (nd.mptr.getlok().getX() == t_p.getX() && nd.mptr.getlok().getY() == t_p.getY()) {

				if(cr.nama_makhluk == 'S') {
					if (nd.nama_makhluk == 'Z' || nd.nama_makhluk == 'I') {
						//singa vs zebra / kelinci -> singa 
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'E') {
						//singa vs elang -> singa 
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'U') {
						//singa vs ular -> singa 
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					}
										
				} else if (cr.nama_makhluk == 'U') {
					if (nd.nama_makhluk == 'Z' || nd.nama_makhluk == 'I') {
						//ular vs zebra / kelinci -> ular
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'S') {
						//ular vs singa -> singa 
						cr.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						nd.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'E') {
						//ular vs elang -> elang 
						cr.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						nd.mptr.setMLapar();
					}
				} else if (cr.nama_makhluk == 'E') {
					if (nd.nama_makhluk == 'Z' || nd.nama_makhluk == 'I') {
						//elang vs zebra / kelinci -> elang  
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'U') {
						//elang vs ular -> elang 
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'S') {
						//elang vs singa -> singa 
						cr.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						nd.mptr.setMLapar();
					}
				} else if (cr.nama_makhluk == 'Z') {
					if (nd.nama_makhluk == 'I') {
						//zebra vs kelinci -> zebra 
						nd.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						cr.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'S' || nd.nama_makhluk == 'E' || nd.nama_makhluk == 'U') {
						//zebra vs singa/elang/ular -> karnivora menang 
						cr.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						nd.mptr.setMLapar();
					} 
				} else if (cr.nama_makhluk == 'I') {
					if (nd.nama_makhluk == 'Z') {
						//kelinci vs zebra -> zebra 
						cr.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						nd.mptr.setMLapar();
					} else if (nd.nama_makhluk == 'S' || nd.nama_makhluk == 'E' || nd.nama_makhluk == 'U') {
						//zebra vs singa/elang/ular -> karnivora menang 
						cr.mptr.setIsExist(0);
						//set level kelaparan menjadi sangat kenyang  
						nd.mptr.setMLapar();
					} 
				}
									
			} 
			nd = nd.next;
		}
	}

}
