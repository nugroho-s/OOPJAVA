/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import oop3.Node;
import oop3.Point;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class PointTest {
    
    public PointTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
     @Test
    public void testgetAbsis() {
        System.out.println("Test get Absis Point");
        
        Point nn = new Point();
        nn.setAbsis(2);
        nn.setOrdinat(3);
        
        assertEquals(nn.getAbsis(),2);
    }
    
    @Test
    public void testgetOrdinat() {
        System.out.println("Test get Ordinat Point");
        
        Point nn = new Point();
        nn.setAbsis(2);
        nn.setOrdinat(3);
        assertEquals(nn.getOrdinat(),3);
    }
    
    @Test
    public void testisOrigin() {
        System.out.println("Test is Origin");
        
        Point nn = new Point();
        nn.setAbsis(0);
        nn.setOrdinat(0);
        
        assertTrue(nn.isOrigin()==1);
    }
    
    @Test
    public void testisEqual() {
        System.out.println("Test is Equal");
        
        Point nn = new Point();
        nn.setAbsis(4);
        nn.setOrdinat(4);
        
        assertTrue(nn.isEqual(nn)==1);
    }
    
     @Test
    public void testkuadran() {
        System.out.println("Test kuadran");
        
        Point nn = new Point();
        nn.setAbsis(4);
        nn.setOrdinat(-3);
        
        assertTrue(nn.kuadran()==4);
    }
}
