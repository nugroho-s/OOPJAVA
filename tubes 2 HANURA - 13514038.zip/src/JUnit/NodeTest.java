/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import oop3.Point;
import oop3.Node;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class NodeTest {
    
    public NodeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void testgetAkar() {
        System.out.println("Test getAkar");
        
        Node nn = new Node();
        assertEquals(nn.getAkar().getAbsis(),0);
        assertEquals(nn.getAkar().getOrdinat(),0);
    }
    
    @Test
    public void testsetAkar() {
        System.out.println("Test set Akar");
        
        Node nn = new Node();
        Point PP = new Point();
        PP.setAbsis(3);PP.setOrdinat(5);
        nn.setAkar(PP);
        
        assertEquals(nn.getAkar().getAbsis(),3);
        assertEquals(nn.getAkar().getOrdinat(),5);
    }
    
    
    
}
