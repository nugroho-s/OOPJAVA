/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import oop3.Point;
import oop3.elang;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.lang.*;
import oop3.singa;

/**
 *
 * @author HP
 */
public class elangTest {
    
    public elangTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void testkonstruktor() {
        System.out.println("Test konstruktor elang");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
        //elang el = new elang(P1,P2,P3,P4);
       // assertEquals(40,el.power);
    }
     @Test
     public void testmakan() {
        System.out.println("Test elang makan");
        Point P1=new Point();P1.setAbsis(1);P1.setOrdinat(1);
        Point P2=new Point();P2.setAbsis(1);P2.setOrdinat(1);
        Point P3=new Point();P3.setAbsis(1);P3.setOrdinat(1);
        Point P4=new Point();P4.setAbsis(1);P4.setOrdinat(1);
        //elang el = new elang(P1,P2,P3,P4);
        
        //try{
        //elang el = new elang(null,null,null,null);
        //}catch (NullPointerException e){}
        //el.makan();
        //assertEquals(20,el.mlapar);
    }
     
}
