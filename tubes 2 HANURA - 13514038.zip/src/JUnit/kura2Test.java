/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import oop3.kura2;
import oop3.Point;
import oop3.singa;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class kura2Test {
    
    public kura2Test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
     @Test
     public void testkonstruktor() {
        System.out.println("Test konstruktor kura2 ");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
        kura2 ku;
        
        //    ku = new kura2(P1,P2,P3,P4);
        //catch (NullPointerException e){}
        //assertEquals(1,ku.power);
    }
      @Test
    public void testmakan() {
        System.out.println("Test kura2 makan");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
        kura2 ku;
        
        //    ku = new kura2(P1,P2,P3,P4);
        //catch (NullPointerException e){}
        //ku.makan();
        //assertEquals(20,ku.mlapar);
    }
     @Test
    public void testlihat() {
        System.out.println("Test kura2 lihat");

    }
}
