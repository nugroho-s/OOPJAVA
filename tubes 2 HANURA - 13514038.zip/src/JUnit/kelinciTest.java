/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import oop3.kelinci;
import oop3.Point;
import oop3.singa;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class kelinciTest {
    
    public kelinciTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
     @Test
    public void testkonstruktorkelinci() {
        System.out.println("Test konstruktor  kelinci");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
       // kelinci kl = new kelinci(P1,P2,P3,P4);
        
        //assertEquals(1,kl.power);
    }
     @Test
    public void testkelincimakan() {
        System.out.println("Test kelinci makan");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
        //kelinci kl;
        
        //    kl = new kelinci(P1,P2,P3,P4);
        //catch (NullPointerException e){}
        //kl.makan();
        //assertEquals(20,kl.mlapar);
    }
     @Test
    public void testkelincimelihat() {
        System.out.println("Test kelinci melihat");
    }
    
}
