/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import oop3.zebra;
import oop3.Point;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author HP
 */
public class zebraTest {
    
    public zebraTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
     @Test
    public void testkonstruktor() {
        System.out.println("Test konstruktor zebra ");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
        //zebra zz;
        
        //    zz = new zebra(P1,P2,P3,P4);
        //catch (NullPointerException e){}
        
        //assertEquals(1,zz.power);
    }
     @Test
    public void testmakan() {
        System.out.println("Test zebra makan");
        Point P1=new Point();P1.setAbsis(14);P1.setOrdinat(12);
        Point P2=new Point();P2.setAbsis(15);P2.setOrdinat(10);
        Point P3=new Point();P3.setAbsis(14);P3.setOrdinat(19);
        Point P4=new Point();P4.setAbsis(18);P4.setOrdinat(17);
        zebra zz;
        
        //    zz = new zebra(P1,P2,P3,P4);
        //catch (NullPointerException e){}
       // zz.makan();
        //assertEquals(20,zz.mlapar);
    }
     @Test
    public void testlihat() {
        System.out.println("Test elang lihat");
    }
}
