/* File name: ReadFileEksternal.java */

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.*;
import java.io.IOException;
/**
 * @author Albertus Kelvin / 13514100
 */
public class ReadFileEksternal {
	/**
         * String yang menyimpan direktori file
         */
        private String path_file;
        /**
         * array of array of char yang menyimpan hasil pembacaan board dan menjadikannya matriks
         */
	private char[][] data_matrix = new char[30][30];
        /**
         * baris dari matriks
         */
	private int matrixRow;
        /**
         * kolom dari matriks
         */
        private int matrixCol;
	
	//constructor
        /**
         * method untuk membuat path dari file
         * @param _path_file , path dari file yang dimasukkan ke dalam atribur
         */
	public ReadFileEksternal(String _path_file) {
		path_file = _path_file;
	}
	
	//getter
        /**
         * method untuk mendapatkan baris matriks
         * @return matrixRow, baris dari matriks
         */
	public int getMatrixRow() {
		return matrixRow;
	}
        
        /**
         * method untuk mendapatkan kolom matriks
         * @return matrixCol, kolom dari matriks
         */
	public int getMatrixCol() {
		return matrixCol;
	}
        
        /**
         * method untuk mendapatkan matriks
         * @return data_matrix, data dari matriks
         */
	public char[][] getDataMatrix() {
		return data_matrix;
	}
	
	//methods
        /**
         * method yang membaca file dan memasukkannya ke dalam matriks
         * @throws IOException , melempar exception jika file tidak diketemukan
         */
	public void startReadingFile() throws IOException {
		String line, token;
		int counter = 0, count_row = 0, count_col = 0;
		StringTokenizer tokenizer;
		BufferedReader input = null;
		input = new BufferedReader(new FileReader(path_file));
		line = input.readLine();
				
		while (line != null) { 
			tokenizer = new StringTokenizer(line, " ");		// delimiternya " "
  
			if (counter == 0) { // menghitung banyak token (jumlah kolom)
				matrixCol = tokenizer.countTokens();
				counter = 1;
			}
			
			count_col = 0;
			while (tokenizer.hasMoreTokens()) {// proses token 
				token = tokenizer.nextToken();
				data_matrix[count_row][count_col] = token.charAt(0);
				count_col++;
			}
			count_row++;
			line = input.readLine(); 
		}// endofwhileline
		
		matrixRow = count_row;
		matrixCol = count_col;
		
		System.out.println("Baris: " + matrixRow);
		System.out.println("Kolom: " + matrixCol);
		
		for (int i = 0; i < matrixRow; i++) {
			for (int j = 0; j < matrixCol; j++) {
				System.out.print(data_matrix[i][j] + " ");
			}
			System.out.println();
		}
		
		input.close();
	}
	
}
 