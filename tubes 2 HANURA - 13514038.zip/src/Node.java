/* File name: Node.java */
/**
 * @author Jeremia Kavin Raja P. / 13514060
 */
public class Node{
	
        /*attributes*/
        /**
         * pointer menuju Node yang ada di timur
         */
	private Node timur;
        /**
         * pointer menuju Node yang ada di tenggara
         */
	private Node tenggara;
        /**
         * pointer menuju Node yang ada di selatan
         */
	private Node selatan;
        /**
         * pointer menuju Node yang ada di baratdaya
         */
	private Node baratdaya;
        /**
         * pointer menuju Node yang ada di barat
         */
	private Node barat;
        /**
         * pointer menuju Node yang ada di baratlaut
         */
	private Node baratlaut;
        /**
         * pointer menuju Node yang ada di utara
         */
	private Node utara;
        /**
         * pointer menuju Node yang ada di timurlaut
         */
	private Node timurlaut;
        /**
         * pointer menuju Node parent
         */
	private Node parent;
        /**
         * Point sebagai isi dari akar sebuah Node
         */
	Point P;
        /**
         * static array of array of int berfungsi untuk mencatat node-node yang pernah dialokasi
         */
	public static int stat[][];
        /**
         * static array of Point berfungsi untuk menyimpan tree yang berhasil dibentuk
         */
	public static Point ptree[];
        /**
         * static int bernilai 1 apabila target dari makhluk tersebut ditemukan, bernilai 0 apabila tidak ditemukan
         */
	public static int found_target;
        /**
         * static Node menunjuk kepada Node yang menjadi akar dari pohon
         */
	public static Node proot;
	
	/**
         * constructor
         */
	public Node(){
		P = new Point();
		timur = null;
		tenggara = null;
		selatan = null;
		baratdaya = null;
		barat = null;
		baratlaut = null;
		utara = null;
		timurlaut = null;
		parent = null;
	}
	
        /**
         * constructor
         * @param x, nilai yang akan menjadi absis dari akar node
         * @param y, nilai yang akan menjadi ordinat dari akar node
         */
	public Node(int x, int y){
		P = new Point();
		P.setAbsis(x);
		P.setOrdinat(y);
		timur = null;
		tenggara = null;
		selatan = null;
		baratdaya = null;
		barat = null;
		baratlaut = null;
		utara = null;
		timurlaut = null;
		parent = null;
	}
	
	/**
         * method untuk mendapatkan akar dari Node
         * @return P, P adalah akar dari Node
         */
	public Point getAkar(){
		return P;
	}
	
        /**
         * method untuk mendapatkan timur dari Node
         * @return timur, timur dari Node
         */
	public Node getTimur(){
		return timur;
	}
	
        /**
         * method untuk mendapatkan tenggara dari Node
         * @return tenggara, tenggara dari Node
         */
	public Node getTenggara(){
		return tenggara;
	}
	
        /**
         * method untuk mendapatkan selatan dari Node
         * @return selatan, selatan dari Node
         */
	public Node getSelatan(){
		return selatan;
	}
	
        /**
         * method untuk mendapatkan baratdaya dari Node
         * @return baratdaya, baratdaya dari Node
         */
	public Node getBaratDaya(){
		return baratdaya;
	}
	
        /**
         * method untuk mendapatkan barat dari Node
         * @return barat, barat dari Node
         */
	public Node getBarat(){
		return barat;
	}
	
        /**
         * method untuk mendapatkan baratlaut dari Node
         * @return baratlaut, baratlaut dari Node
         */
	public Node getBaratLaut(){
		return baratlaut;
	}
	
        /**
         * method untuk mendapatkan utara dari Node
         * @return utara, utara dari Node
         */
	public Node getUtara(){
		return utara;
	}
	
        /**
         * method untuk mendapatkan timurlaut dari Node
         * @return timurlaut, timurlaut dari Node
         */
	public Node getTimurLaut(){
		return timurlaut;
	}
	
        /**
         * method untuk mendapatkan parent dari Node
         * @return parent, parent dari Node
         */
	public Node getParent(){
		return parent;
	}
	
	/**
         * method untuk mengatur akar dari Node
         * @param x , nilai yang akan diatur menjadi absis dari akar Node
         * @param y , nilai yang akan diatur menjadi ordinat dari akar Node
         */
	public void setAkar(int x, int y){
		P.setAbsis(x);
		P.setOrdinat(x);
	}
	
        /**
         * method untuk mengatur akar dari Node
         * @param _P , Point yang akan diatur menjadi akar Node
         */
	public void setAkar(Point _P){
		P.setAbsis(_P.getAbsis());
		P.setOrdinat(_P.getOrdinat());
	}
	
        /**
         * method untuk mengatur timur dari Node
         * @param n , Node yang akan diatur menjadi timur dari Node
         */
	public void setTimur(Node n){
		timur = new Node();
		timur = n;
	}
	
        /**
         * method untuk mengatur tenggara dari Node
         * @param n , Node yang akan diatur menjadi tenggara dari Node
         */
	public void setTenggara(Node n){
		tenggara = new Node();
		tenggara = n;
	}
	
        /**
         * method untuk mengatur selatan dari Node
         * @param n , Node yang akan diatur menjadi selatan dari Node
         */
	public void setSelatan(Node n){
		selatan = new Node();
		selatan = n;
	}
	
        /**
         * method untuk mengatur baratdaya dari Node
         * @param n , Node yang akan diatur menjadi baratdaya dari Node
         */
	public void setBaratDaya(Node n){
		baratdaya = new Node();
		baratdaya = n;
	}
	
        /**
         * method untuk mengatur barat dari Node
         * @param n , Node yang akan diatur menjadi barat dari Node
         */
	public void setBarat(Node n){
		barat = new Node();
		barat = n;
	}
	
        /**
         * method untuk mengatur baratlaut dari Node
         * @param n , Node yang akan diatur untuk menjadi baratlaut dari Node
         */
	public void setBaratLaut(Node n){
		baratlaut = new Node();
		baratlaut = n;
	}
	
        /**
         * method untuk mengatur utara dari Node
         * @param n , Node yang akan diatur untuk menjadi utara dari Node
         */
	public void setUtara(Node n){
		utara = new Node();
		utara = n;
	}
	
        /**
         * method untuk mengatur timurlaut dari Node
         * @param n , Node yang akan diatur untuk menjadi timurlaut dari Node
         */
	public void setTimurLaut(Node n){
		timurlaut = new Node();
		timurlaut = n;
	}
	
        /**
         * method untuk mengatur parent dari Node
         * @param n , Node yang akan diatur untuk menjadi parent dari Node
         */
	public void setParent(Node n){
		parent = new Node();
		parent = n;
	}
	
        /**
         * method untuk mengatur Node itu sendiri
         * @param n , Node yang akan diatur untuk menjadi pengganti Node itu sendiri
         */
	public void set(Node n){
		setAkar(n.getAkar());
		setTimur(n.getTimur());
		setTenggara(n.getTenggara());
		setSelatan(n.getSelatan());
		setBaratDaya(n.getBaratDaya());
		setBarat(n.getBarat());
		setBaratLaut(n.getBaratLaut());
		setUtara(n.getUtara());
		setTimurLaut(n.getTimurLaut());
		setParent(n.getParent());
	}
}
