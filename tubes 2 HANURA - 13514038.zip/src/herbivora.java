/**
 * 
 * @author Nugroho Satriyanto / 13514038
 */
public abstract class herbivora extends makhluk {
    /**
     * level kelaparan sebuah objek turunan herbivora 
     */
    protected int mlapar;
    /**
     * pointer terhadap objek yang mengejar
     */
    protected makhluk dikejar;
    /**
     * maxlapar herbivora
     */
    protected final int maxlapar = 20;
    /**
     * list path yang akan ditempuh
     */
    protected list LOP;

    /**
     * konstruktor
     * @param p1 , Point batas
    * @param p2 , Point batas
    * @param p3 , Point batas
    * @param p4 , Point batas
     */
    public herbivora(Point p1, Point p2, Point p3, Point p4){
        super(board.isi, 'h', p1, p2, p3, p4);
    }
    
    /**
     * mengembalikan hewan karnivora
     * @return , hewan yang mengejar
     */
    public makhluk getkejar() {
		return dikejar;
    }
    /**
     * menaikkan level ke maksimum
     */
    public abstract void makan();
    /**
     * membuat lintasan ke tujuan
     * @param p , point tujuan
     */
    public abstract void makepath(final Point p);
    /**
     * mengisi LOP
     */
    public void isiLOP() {
		LOP.printListPath(LOP.headp);
    }
    /**
     * menghapus path
     */
    public void delpath() {
		LOP.deleteAllPath();
    }
    
	public Point getElmtLOP(int idxObj) {
		list.path curr = new list.path();
		curr = LOP.headp;
		int counter = 0;
		int found = 0;
		
		while (curr != null) {
			if (counter == idxObj) {
				found = 1;
				return curr.P;
			}
			counter++;
			curr = curr.nextp;
		}
		
		if (found == 0) {
			return LOP.tailp.P;
		}
		return null;
    }
        /**
         * menggerakkan makhluk
         * @param ch , karakter makhluk
         * @param s , lokasi awal
         * @param p , lokasi tujuan
         */
    public void bergerak(char ch, Point s, Point p) {
        /*  bergerak ke koordinat (p.x, p.y)
            level kelaparan berkurang menjadi semakin lapar
		*/
		mlapar--;

		board.isi[s.getY()][s.getX()] = board.const_isi[s.getY()][s.getX()];
		board.isi[p.getY()][p.getX()] = ch;
	
		if (mlapar < 0) {
            isExist = 0;
		}
    }
	/**
         * mengembalikan level kelaparan sebuah objek herbivora 
         * @return tingkat kelaparan
         */
    public int getlapar() {
		return mlapar;
    }
    /**
     * set mlapar
     */
    public void setMLapar() {
		mlapar = maxlapar;
    }
    /**
     * set atribut pengejar
     * @param ms , makhluk yang mengejar
     */
    public void setkejar(makhluk ms) {
		dikejar = ms;
    }
}