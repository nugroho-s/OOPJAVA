/**
 * 
 * @author Jeremia Kavin Raja P / 13514060
 */

public abstract class karnivora extends makhluk {
	/**
         * level kelaparan sebuah objek turunan herbivora 
         */
	protected int mlapar;
        /**
         * jenis makanan
         */
	protected int jenismakanan;
        /**
         * makhluk yang dikejar
         */
	protected makhluk mengejar;
        /**
         * maksimum kelaparan
         */
	protected final int maxlapar = 20;
        /**
         * list jalur
         */
	protected list LOP;
	/**
         * iterator list makhluk
         */
	public static list.node iterate_lom;
        /**
         * node sekarang
         */
	public static list.node kar;
	
	/**
         * constructor
         * @param p1 , Point batas
         * @param p2 , Point batas
         * @param p3 , Point batas
         * @param p4 , Point batas
         */
	public karnivora(Point p1, Point p2, Point p3, Point p4){
		super(board.isi, 'k', p1, p2, p3, p4);
	}
	
	/**
         * mengembalikan makhluk yang dikejar
         * @return , makhluk yang dikejar
         */
	public makhluk getkejar(){
		return mengejar;
	}
        /**
         * mengembalikan elemen path
         * @param idxObj , id dari makhluk
         * @return , point path
         */
	public Point getElmtLOP(int idxObj){
		list.path curr =  new list.path();
		curr = LOP.headp;
		int counter = 0;
		int found = 0;
		
		while (curr != null) {
			if (counter == idxObj) {
				found = 1;
				break;
			}
			counter++;
			curr = curr.nextp;
		}
		
		if (found == 0) {
			return LOP.tailp.P;
		} else {
			return curr.P;
		}
	}
        /**
         * mengembalikan level kelaparan
         * @return , level lapar
         */
	public int getlapar(){
		return mlapar;
	}
	
	/**
         * set kelaparan
         */
	public void setMLapar(){
		mlapar = maxlapar;
	}
        /**
         * set objek yang dikejar
         * @param ms , Makhluk terkejar
         */
	public void setkejar(makhluk ms){
		mengejar = ms;
	}
	
	/**
         * mengembalikan level kelaparan
         */
	public abstract void makan();
        /**
         * membuat path
         * @param p , point tujuan
         */
	public abstract void makepath(final Point p);
	/**
         * mengisi list jalur
         */
	public void isiLOP(){
		LOP.printListPath(LOP.headp);
	}
	/**
         * menghapus list jalur
         */
	public void delpath(){
		LOP.deleteAllPath();
	}
	/**
         * menggerakkan objek
         * @param ch , karakter makhluk
         * @param s , point asal
         * @param p , point tujuan
         */
	public void bergerak(char ch, Point s, Point p){
		mlapar--;
	
		board.isi[s.getY()][s.getX()] = board.const_isi[s.getY()][s.getX()];
		board.isi[p.getY()][p.getX()] = ch;

		if (mlapar < 0) {
			isExist = 0;
		}
	}

	public void lihat(Point _target){
		int IndexX = getlok().getX();
		int IndexY = getlok().getY();
		int _getarah = getarah();
		
		Point temp = new Point();
		
		list.node ilom = iterate_lom;
		list.node ikar = kar;
		
		if (_getarah == 0) {
			// mendeteksi sepanjang garis timur 
			while (IndexX < board.sizex) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexX++;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
			
		} else if (_getarah == 1) {
			// mendeteksi sepanjang garis tenggara 
			while (IndexX < board.sizex && IndexY < board.sizey) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexX++; IndexY++;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
			
		} else if (_getarah == 2) {
			// mendeteksi sepanjang garis selatan
			while (IndexY < board.sizey) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexY++;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
			
		} else if (_getarah == 3) {
			// mendeteksi sepanjang garis barat daya 
			while (IndexX >= 0 && IndexY < board.sizey) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexX--; IndexY++;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
			
		} else if (_getarah == 4) {
			// mendeteksi sepanjang garis barat 
			while (IndexX >= 0) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexX--;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
			
		} else if (_getarah == 5) {
			// mendeteksi sepanjang garis barat laut 
			while (IndexX >= 0 && IndexY >= 0) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexX--; IndexY--;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
			
		} else if (_getarah == 6) {
			// mendeteksi sepanjang utara 
			while (IndexY >= 0) {
				
				iterate_lom = ilom;
				kar = ikar;
			
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexY--;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
		
		} else if (_getarah == 7) {
			// mendeteksi sepanjang garis timur laut  
			while (IndexX < board.sizex && IndexY >= 0) {
				
				iterate_lom = ilom;
				kar = ikar;
				
				point_in_while(temp, IndexX, IndexY, _getarah);
				if (temp.getX() == -2 && temp.getY() == -2) {
					//normal return, lanjutkan while loop 
					IndexX++; IndexY--;
				} else {
					//antara mendeteksi atau tidak 
					break;
				}
			}
			_target.set(temp.getX(), temp.getY());
		}
	}
            /**
             * untuk melihat
             * @param _target , tujuan pandangan
             * @param _IndexX , indeks x makhluk
             * @param _IndexY , indeks y makhluk
             * @param _arah , arah makhluk
             */
	public void point_in_while(Point _target, int _IndexX, int _IndexY, int _arah) {
		
		int found = 0, found_x = -1, found_y = -1;
		
		if (board.isi[_IndexY][_IndexX] != '!') {
			
			//iterasi list 
			while (iterate_lom != null) {
				
				if (iterate_lom.mptr.getIsExist() == 1) {
				
					if (iterate_lom.mptr.getlok().getX() == _IndexX && iterate_lom.mptr.getlok().getY() == _IndexY) {
						
						if (iterate_lom.mptr.getid() == 'h' && iterate_lom.nama_makhluk != 'K') {
							found = 1;
							found_x = _IndexX;
							found_y = _IndexY;
							break;
						}
			
					}
				
				}
			
				iterate_lom = iterate_lom.next;
			}
			
			if (found == 1) {
				//detected return  
				_target.set(found_x, found_y);
			} else {
				if (_arah == 0 && _IndexX == board.sizex - 1) {	//non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 1 && (_IndexX == board.sizex - 1 || _IndexY == board.sizey - 1)) { //non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 2 && _IndexY == board.sizey - 1) { //non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 3 && (_IndexX == 0 || _IndexY == board.sizey - 1)) { //non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 4 && _IndexX == 0) { //non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 5 && (_IndexX == 0 || _IndexY == 0)) { //non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 6 && _IndexY == 0) { //non-detected return 
					_target.set(-1, -1);
				} else if (_arah == 7 && (_IndexX == board.sizex - 1 || _IndexY == 0)) { //non-detected return 
					_target.set(-1, -1);
				} else { //normal return
					_target.set(-2, -2);
				}
			}
		} else {
			//non-detected return 
			_target.set(-1, -1);
		}
	}

}
