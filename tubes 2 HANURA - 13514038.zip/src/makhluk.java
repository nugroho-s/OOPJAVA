
import java.util.*;
/**
 * 
 * @author Albertus Kelvin / 13514100
 */
public abstract class makhluk {
	/**
         * id (h = herbivora; k = karnivora)
         */
	protected char id;			// id objek turunan makhluk (h = herbivora atau k = karnivora)
        /**
         * id unik
         */
	protected int unique;
        /**
         * counter makhluk
         */
	protected static int unique_counter = 0;
        /**
         * hidup
         */
	protected int isExist;
        /**
         * waktu bergerak
         */
	protected int dt;			// selang waktu gerak sebuah objek turunan makhluk 
        /**
         * kekuatan sebuah objek turunan makhluk (berguna saat sebuah sel board ditempati lebih dari 1 makhluk) 
         */
	protected int power;		// 
        /**
         * arah gerakan
         */
	protected int arah;			// arah gerak sebuah objek turunan makhluk 
        /**
         * timer yang mengontrol kapan sebuah makhluk bergerak berdasarkan global time 
         */
	protected int mtimer;
        /**
         * langkah maksimum makhluk saat dikejar (herbivora) atau mengejar (karnivora) 
         */
	protected int lgkh_max;
        /**
         * koordinat sebuah objek turunan makhluk di bidang 
         */
	protected Point P = new Point();
        /**
         * lokasi target yang dituju 
         */
	protected Point target = new Point();	// 
	
	/**
         * konstruktor
         * @param bid , bidang dunia
         * @param jenis_obj , jenis objek
         * @param min_h_v , batas
         * @param max_h_v , batas
         * @param min_h_h , batas
         * @param max_h_h , batas
         */
	public makhluk(char[][] bid, char jenis_obj, Point min_h_v, Point max_h_v, Point min_h_h, Point max_h_h) {

		//KAMUS
		int found = 0, x = 0, y = 0;
		Random rand = new Random();
		
		//ALGORITMA
		
		System.out.println("ctor makhluk");
		System.out.println(min_h_v.getX() + ", " + min_h_v.getY());
		System.out.println(max_h_v.getX() + ", " + max_h_v.getY());
		System.out.println(min_h_h.getX() + ", " + min_h_h.getY());
		System.out.println(max_h_h.getX() + ", " + max_h_h.getY());
		
		
		/** inisiasi nilai koordinat awal objek (x, y) dengan nilai random **/	
		while (found == 0) {
			
			x = rand.nextInt(max_h_v.getX()) + min_h_v.getX();
			y = rand.nextInt(max_h_h.getY()) + min_h_h.getY();
				
			System.out.println("xy: " + x + ", " + y);
			
			if (bid[y][x] == jenis_obj) {
				found = 1;
			}
		}
		
		System.out.println("pass while found " + x + ", " + y);
		
		P = new Point();
		P.set(x, y);
		
		/** inisiasi atribut id **/ 
		id = jenis_obj;
		
		/** inisiasi nilai eksistensi makhluk **/ 
		isExist = 1;
		
		/** inisiasi nilai arah gerak awal objek dengan nilai random (0 - 7) **/
		arah = rand.nextInt(7) + 0;
		
		/** inisiasi nilai mtimer  **/
		mtimer = 0;
		
		/** inisiasi unique makhluk **/
		unique_counter++; 
		unique = unique_counter;
		
	}
	
	/**
         * method yang menghasilkan posisi baru sebuah makhluk setelah bergerak acak sesuai arah tertentu
         * @param bid , matriks dunia sabana 
         * @param buff_sizex , ukuran dunia
         * @param buff_sizey , ukuran dunia
         * @return , point akhir setelah bergerak acak sesuai arah tertentu
         */
	public Point bergerak_random(char[][] bid, int buff_sizex, int buff_sizey) {
		//makhluk berpindah ke posisi lain secara random sesuai arah geraknya
		/** 
		* ketentuan: 
		* 0 : timur
		* 1 : tenggara
		* 2 : seltan
		* 3 : barat daya
		* 4 : barat 
		* 5 : barat laut
		* 6 : utara
		* 7 : timur laut
		*/
		
		//KAMUS 
		Point newPosition = new Point();		//posisi baru setelah bergerak random 
		Random rand = new Random();
		
		//ALGORITMA
		if (arah == 0) {
			if (P.getX() + 1 < buff_sizex) {
				if (bid[P.getY()][P.getX()+1] == '!' || bid[P.getY()][P.getX()+1] == 'x' || bid[P.getY()][P.getX()+1] == 'y') {
					while (arah == 0) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX() + 1, P.getY());
				}
			} else {
				while (arah == 0) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 1) {
			if (P.getX() + 1 < buff_sizex && P.getY() + 1 < buff_sizey) {
				if (bid[P.getY()+1][P.getX()+1] == '!' || bid[P.getY()+1][P.getX()+1] == 'x' || bid[P.getY()+1][P.getX()+1] == 'y') {
					while (arah == 1) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX() + 1, P.getY()+1);
				}
			} else {
				while (arah == 1) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 2) {
			if (P.getY() + 1 < buff_sizey) {
				if (bid[P.getY()+1][P.getX()] == '!' || bid[P.getY()+1][P.getX()] == 'x' || bid[P.getY()+1][P.getX()] == 'y') {
					while (arah == 2) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX(), P.getY()+1);
				}
			} else {
				while (arah == 2) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 3) {
			if (P.getX() - 1 >= 0 && P.getY() + 1 < buff_sizey) {
				if (bid[P.getY()+1][P.getX()-1] == '!' || bid[P.getY()+1][P.getX()-1] == 'x' || bid[P.getY()+1][P.getX()-1] == 'y') {
					while (arah == 3) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX()-1, P.getY()+1);
				}
			} else {
				while (arah == 3) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 4) {
			if (P.getX() - 1 >= 0) {
				if (bid[P.getY()][P.getX()-1] == '!' || bid[P.getY()][P.getX()-1] == 'x' || bid[P.getY()][P.getX()-1] == 'y') {
					while (arah == 4) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX() - 1, P.getY());
				}
			} else {
				while (arah == 4) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 5) {
			if (P.getX() - 1 >= 0 && P.getY() - 1 >= 0) {
				if (bid[P.getY()-1][P.getX()-1] == '!' || bid[P.getY()-1][P.getX()-1] == 'x' || bid[P.getY()-1][P.getX()-1] == 'y') {
					while (arah == 5) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX()-1, P.getY()-1);
				}
			} else {
				while (arah == 5) {
				arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 6) {
			if (P.getY() - 1 >= 0) {
				if (bid[P.getY()-1][P.getX()] == '!' || bid[P.getY()-1][P.getX()] == 'x' || bid[P.getY()-1][P.getX()] == 'y') {
					while (arah == 6) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX(), P.getY()-1);
				}
			} else {
				while (arah == 6) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		} else if (arah == 7) {
			if (P.getX() + 1 < buff_sizex && P.getY() - 1 >= 0) {
				if (bid[P.getY()-1][P.getX()+1] == '!' || bid[P.getY()-1][P.getX()+1] == 'x' || bid[P.getY()-1][P.getX()+1] == 'y') {
					while (arah == 7) {
						arah = rand.nextInt(7) + 0;
					}
					newPosition.set(P.getX(), P.getY());
				} else {
					newPosition.set(P.getX() + 1, P.getY() - 1);
				}
			} else {
				while (arah == 7) {
					arah = rand.nextInt(7) + 0;
				}
				newPosition.set(P.getX(), P.getY());
			}
		}
		
		return newPosition;
	}
	
	/**
	* @Override by subclasses
	*/
	/**
         * method untuk makhluk bergerak
         * @param ch , karakter makhluk
         * @param s , posisi makhluk mula-mula
         * @param p , posisi tujuan makhluk
         */
        public abstract void bergerak(char ch, Point s, Point p);
	
        /**
         * method untuk makhluk melihat
         * @param p , Point yang dilihat
         */
        public abstract void lihat(Point p);
	
	/**
	* @Abstract Method - MUST be implemented by subclasses 
	*/
        /**
         * method untuk makhluk makan
         */
	public abstract void makan();
        
        /**
         * method untuk membuat path makhluk
         * @param p , Point posisi makhluk
         */
	public abstract void makepath(Point p);
	
        /**
         * method untuk mengisi list of path
         */
        public abstract void isiLOP();
        
        /**
         * method untuk mengetahui makhluk apa yang dikejar
         * @return makhluk, makhluk yang dikejar
         */
	public abstract makhluk getkejar();
        
        /**
         * method untuk mendapatkan elemen List of Path berindeks idxObj
         * @param idxObj ,  indeks list yang mau diambil
         * @return Point, Point yang ingin diambil
         */
	public abstract Point getElmtLOP(int idxObj);
	
        /**
         * method untuk menghapus path
         */
        public abstract void delpath();
	
	/**
	* GETTER 
	*/
	
	/**
	* @Abstract Getter - MUST be implemented by subclasses 
	*/
        /**
         * method untuk mengetahui level kelaparan makhluk
         * @return int, level lapar
         */
	public abstract int getlapar();
	
        /**
         * method yang mengembalikan posisi makhluk di board saat itu
         * @return P , posisi makhluk di board saat itu
         */
	public Point getlok() {
		// mengembalikan posisi (x, y) objek di bidang 
		return P; 
	}
        
        /**
         * method yang mengembalikan posisi target sebuah makhluk di board
         * @return target , posisi target sebuah makhluk di board
         */
	public Point gettarget() {
		// mengembalikan posisi target (x, y) di bidang 
		return target;
	}
        
        /**
         * method yang mengembalikan identitas dari sebuah makhluk
         * @return id , identitas dari jenis sebuah makhluk
         */
	public char getid() {
		return id;
	}
        
        /**
         * method yang mengembalikan ID unik sebuah makhluk
         * @return unique , sebuah ID unik sebuah makhluk
         */
	public int getunique() {
		return unique;
	}
        
        /**
         * method yang mengembalikan nilai waktu gerak sebuah makhluk
         * @return dt , batas waktu gerak sebuah makhluk
         */
	public int getdt() {
		return dt;
	}
        
        /**
         * method yang mengembalikan nilai power sebuah makhluk
         * @return power , nilai kekuatan sebuah makhluk
         */
	public int getpower() {
		return power;
	}
        
        /**
         * method yang mengembalikan arah gerak sebuah makhluk
         * @return arah , nilai yang menunjukkan arah gerak sebuah makhluk
         */
	public int getarah() {
		return arah;
	}
        
        /**
         * method yang mengembalikan nilai mtimer sebuah makhluk
         * @return mtimer , sebuah counter untuk menentukan kapan makhluk harus bergerak
         */
	public int getMTimer() {
		return mtimer;
	}
        
        /**
         * method yang mengembalikan langkah maksimum sebuah makhluk
         * @return lgkh_max , langkah maksmum yang bisa diambil sebuah makhluk
         */
	public int getLMax() {
		return lgkh_max;
	}
        
        /**
         * method yang mengembalikan nilai isExist sebuah makhluk
         * @return isExist , keberadaan sebuah makhluk
         */
	public int getIsExist() {
		return isExist;
	}
	
	/**
	* SETTER 
	*/
	
	/**
	* @Abstract Setter - MUST be implemented by subclasses 
	*/
        /**
         * method untuk mengatur level kelaparan
         */
	public abstract void setMLapar() ;
        
        /**
         * method untuk membuat makhluk mengejar makhluk lainnya
         * @param ms , makhluk yang dikejar
         */
	public abstract void setkejar(makhluk ms);
	
        /**
         * set id unik
         * @param u , id unik
         */
	public void setUnique(int u) {
		unique = u;
	}
        /**
         * set target
         * @param p , lokasi target
         */
	public void setTarget(Point p) {
		target.set(p.getX(), p.getY());
	}
        /**
         * set point
         * @param p , lokasi baru
         */
	public void setP(Point p) {
		P.set(p.getX(), p.getY());
	}
        /**
         * setter setTimer
         * @param mt , mtimer baru
         */
	public void setMTimer(int mt) {
		mtimer = mt;
	}
        /**
         * setter isExist
         * @param ie , isExist baru
         */
	public void setIsExist(int ie) {
		isExist = ie;
	}
	
	/**
         * print lokasi makhluk
         */
	public void printlok() {
		// menampilkan lokasi (x, y) sebuah objek turunan makhluk di bidang 
		System.out.println("Lokasi: (" + P.getX() + ", " + P.getY() +")");
	}
        /**
         * print id
         * @param st, string keluaran 
         */
	public void printunique(String st) {
		// menampilkan unique makhluk
		System.out.println("ID unik " + st + ": " + unique);
	}
        /**
         * print status gerakan
         * @param s , awal
         * @param p , akhir
         */
	public void printstatgerak(Point s, Point p) {
		// menampilkan status pergerakan makhluk
		System.out.println("Jenis makhluk: " + id); 
		if (id == 'k') {
			System.out.println("Arah makhluk: " + arah);
		}
		System.out.println("Posisi awal: " + s.getX() + ", " + s.getY());
		System.out.println("Posisi tujuan: " + p.getX() + ", " + p.getY());
	}
        /**
         * method yang akan menampilkan level kelaparan
         */
	public void printstatkelaparan() {
		// menampilkan status level kelaparan makhluk
		System.out.println("Level kelaparan: " + getlapar());
	}
	
}