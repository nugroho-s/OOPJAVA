/* File: board.java */

import java.io.IOException;
/**
 * @author Albertus Kelvin / 13514100
 */
public class board {
        /**
         * panjang board
         */
	public static int sizex;					// panjang board 
	/**
         * lebar board
         */
        public static int sizey;					// lebar board 
        /**
         * batasan minimal vertikal dari hewan herbivora
         */
	public static Point min_h_vertical;
        /**
         * batasan minimal vertikal dari hewan karnivora
         */
	public static Point min_k_vertical;
        /**
         * batasan maksimal vertikal dari hewan herbivora
         */
	public static Point max_h_vertical;
        /**
         * batasan maksimal vertikal dari hewan karnivora
         */
	public static Point max_k_vertical;
        /**
         * batasan minimal horizontal dari hewan herbivora
         */
	public static Point min_h_horizontal;
        /**
         * batasan minimal horizontal dari hewan karnivora
         */
	public static Point min_k_horizontal;
        /**
         * batasan maksimal horizontal dari hewan herbivora
         */
	public static Point max_h_horizontal;
        /**
         * batasan maksimal horizontal dari hewan karnivora
         */
	public static Point max_k_horizontal;
        
        /**
         * lokasi pintu benteng utara
         */
	public static Point pintu_u;
        /**
         * lokasi pintu benteng selatan
         */
	public static Point pintu_s;
        /**
         * array 2D dinamis isi dari board
         */
	public static char[][] isi;
        /**
         * array 2D dinamis isi permanen dari board
         */
	public static char[][] const_isi;			//array 2D dinamis  
	
	/**
         * constructor
         */
	public board() {
		
		//KAMUS
		String path_file = "C:/Users/Raja Siahaan/Desktop/Tubes2/board.txt";
		int[] arrPosition = new int[2];		//return absis dan ordinat
		
		//ALGORITMA
		
		/** membuat objek pembaca file **/
		ReadFileEksternal RFE = new ReadFileEksternal(path_file);
		
		/** membaca board dari file **/ 
		try {
			RFE.startReadingFile();
		} catch (IOException e) {
			System.err.println("IOException baca file: " + e.getMessage());
		}
		
		/** alokasi matriks board **/
		sizex = RFE.getMatrixCol();
		sizey = RFE.getMatrixRow();
		isi = new char[sizey][sizex];
		const_isi = new char[sizey][sizex];
		
		/** inisiasi matriks board **/
		isi = RFE.getDataMatrix();
		const_isi = RFE.getDataMatrix();
		
		/** inisiasi posisi pintu utara dan selatan **/
		pintu_u = new Point();
		pintu_s = new Point();
		for (int i = 0; i < sizey; i++) {
			for (int j = 0; j < sizex; j++) {
				if (isi[i][j] == 'x') {
					pintu_u.set(j, i);
				} else if (isi[i][j] == 'y') {
					pintu_s.set(j, i);
				}
			}
		}
		
		/** inisiasi nilai min_h dan max_h utk HERBIVORA **/ 
		min_h_vertical = new Point();	
		arrPosition = min_h_ver('h');
		min_h_vertical.set(arrPosition[0], arrPosition[1]);
		
		max_h_vertical = new Point();
		arrPosition = max_h_ver('h');
		max_h_vertical.set(arrPosition[0], arrPosition[1]);
		
		min_h_horizontal = new Point();
		arrPosition = min_h_hor('h');
		min_h_horizontal.set(arrPosition[0], arrPosition[1]);
		
		max_h_horizontal = new Point();
		arrPosition = max_h_hor('h');
		max_h_horizontal.set(arrPosition[0], arrPosition[1]);
		
		/** inisiasi nilai min_h dan max_h utk KARNIVORA **/
		min_k_vertical = new Point();	
		arrPosition = min_h_ver('k');
		min_k_vertical.set(arrPosition[0], arrPosition[1]);
		
		max_k_vertical = new Point();
		arrPosition = max_h_ver('k');
		max_k_vertical.set(arrPosition[0], arrPosition[1]);
		
		min_k_horizontal = new Point();
		arrPosition = min_h_hor('k');
		min_k_horizontal.set(arrPosition[0], arrPosition[1]);
		
		max_k_horizontal = new Point();
		arrPosition = max_h_hor('k');
		max_k_horizontal.set(arrPosition[0], arrPosition[1]);
		
	}
	
	/**
         * method yang mengembalikan koordinat dari batasan makhluk herbivora untuk vertikal kiri
         * @param jns_obj , jenis objek yang akan dicari batasannya
         * @return arrPos , array of int yang menyimpan koordinat batasan makhluk herbivora vertikal kiri
         */
	public int[] min_h_ver(char jns_obj) {
		// batasan nilai random untuk vertikal kiri
		//KAMUS 
		int i=0, j=0, found = 0;
		int[] arrPos = new int[2];
		
		//ALGORITMA 
		for (i = 0; i < sizex; i++) {
			for (j = 0; j < sizey; j++) {
				if (isi[j][i] == jns_obj) {
					found = 1;
					break;
				}
			}
			if (found == 1) {
				break;
			}
		}
		
		arrPos[0] = i;
		arrPos[1] = j;
		
		return arrPos;
	}
	
        /**
         *  method yang mengembalikan koordinat dari batasan makhluk herbivora untuk vertikal kanan
         * @param jns_obj , jenis objek yang akan dicari batasannya
         * @return arrPos , array of int yang menyimpan koordinat batasan makhluk herbivora vertikal kanan
         */
	public int[] max_h_ver(char jns_obj) {
		// batasan nilai random untuk vertikal kanan 
		//KAMUS 
		int i=0, j=0, found = 0;
		int[] arrPos = new int[2];
		
		//ALGORITMA 
		for (i = sizex-1; i >= 0; i--) {
			for (j = 0; j < sizey; j++) {
				if (isi[j][i] == jns_obj) {
					found = 1;
					break;
				}
			}
			if (found == 1) {
				break;
			}
		}
		
		arrPos[0] = i;
		arrPos[1] = j;
		
		return arrPos;
	}
	
        /**
         *  method yang mengembalikan koordinat dari batasan makhluk herbivora untuk horizontal atas
         * @param jns_obj , jenis objek yang akan dicari batasannya
         * @return arrPos , array of int yang menyimpan koordinat batasan makhluk herbivora horizontal atas
         */
         
	public int[] min_h_hor(char jns_obj) {
		// batasan nilai random untuk horizontal atas
		//KAMUS 
		int i=0, j=0, found = 0;
		int[] arrPos = new int[2];
		
		//ALGORITMA
		for (i = 0; i < sizey; i++) {
			for (j = 0; j < sizex; j++) {
				if (isi[i][j] == jns_obj) {
					found = 1;
					break;
				}
			}
			if (found == 1) {
				break;
			}
		}
		arrPos[0] = j;
		arrPos[1] = i;
		
		return arrPos;
	}
		
	/**
         *  method yang mengembalikan koordinat dari batasan makhluk herbivora untuk horizontal bawah
         * @param jns_obj , jenis objek yang akan dicari batasannya
         * @return arrPos , array of int yang menyimpan koordinat batasan makhluk herbivora horizontal bawah
         */
        public int[] max_h_hor(char jns_obj) {
		// batasan nilai random untuk horizontal bawah
		//KAMUS 
		int i=0, j=0, found = 0;
		int[] arrPos = new int[2];
		
		//ALGORITMA
		for (i = sizey-1; i >= 0; i--) {
			for (j = 0; j < sizex; j++) {
				if (isi[i][j] == jns_obj) {
					found = 1;
					break;
				}
			}
			if (found == 1) {
				break;
			}
		}
		arrPos[0] = j;
		arrPos[1] = i;
		
		return arrPos;
	}
		
        /**
         * method untuk mencetak board ke layar
         */
	public void printboard() {
		//print kondisi dunia saat ini
		System.out.println("[PRINT BOARD]: SABANA");
		System.out.println("---------------------");
		for (int i = 0; i < sizey; i++) {
			for (int j = 0; j < sizex; j++) {
				System.out.print(const_isi[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("---------------------");
	}

        /**
         * method untuk menambahkan makhluk ke board
         * @param ms , makhluk yang akan ditambahkan
         * @param ch , karakter yang merepresentasikan keberadaan makhluk tersebut
         */
	public void tambah(makhluk ms, char ch) {
		//tambahkan makhluk ke papan
		Point P = new Point();
		P = ms.getlok();
		isi[P.getY()][P.getX()] = ch;
	}
	
        /**
         * method untuk menghapus suatu makhluk dari board
         * @param ms , makhluk yang akan dihapus
         */
	public void hapus(makhluk ms) {
		//hapus makhluk dari papan
		Point P = new Point();
		P = ms.getlok();
		isi[P.getY()][P.getX()] = const_isi[P.getY()][P.getX()];
	}
	
}